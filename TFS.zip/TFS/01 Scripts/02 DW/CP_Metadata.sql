
IF OBJECT_ID(N'[dbo].[Form]', N'U') IS NULL
BEGIN
CREATE TABLE [dbo].[Form](
	[Form] [varchar](200) NULL,
	[StartString] [varchar](200) NULL,
	[EndString] [varchar](1000) NULL,
	[FilterPatent] [varchar](1000) NULL,
	[Active] [int] NOT NULL,
	[NBR] [int] NULL
) ON [PRIMARY]
END

IF OBJECT_ID(N'[dbo].[Tag]', N'U') IS NULL
BEGIN
CREATE TABLE [dbo].[Tag](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Value] [varchar](200) NULL
) ON [PRIMARY]
END

INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'0.01 Business Case Title', N'<w:alias w:val="0.01 Business Case Title"/>', N'<w:t xml:space="preserve">Creation </w:t></w:r>', N'AND ([Column 0] like ''<w:t>%'')', 1, 1)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'0.02 Creation Date', N'<w:alias w:val="0.02 Creation Date"/>', N'<w:alias w:val="0.03 Business Case Reference"/>', N'AND [Column 0] like ''<w:date w:fullDate="%">''', 1, 2)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'0.03 Business Case Reference', N'<w:alias w:val="0.03 Business Case Reference"/>', N'', N'', 1, 3)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'0.04 Business Case Type', N'<w:alias w:val="0.04 Business Case Type"/>', N'<w:alias w:val="0.05 Department"/>', N'AND [Column 0] like ''<w:t>%'' AND CONVERT(VARCHAR(200),[Column 0]) <>''<w:t>Department''', 1, 4)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'0.05 Department', N'<w:alias w:val="0.05 Department"/>', N'<w:alias w:val="0.06 Business Case Sponsor"/>', N'AND [Column 0] like ''<w:t>%'' AND CONVERT(VARCHAR(200),[Column 0]) NOT IN (''<w:t xml:space="preserve">Business '',''<w:t>Case Sponsor'',''<w:t>(s)'')', 1, 5)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'0.06 Business Case Sponsor', N'<w:alias w:val="0.06 Business Case Sponsor"/>', N'', N'', 1, 6)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'0.07 Department Sponsor', N'<w:alias w:val="0.07 Department Sponsor"/>', N'', N'', 1, 7)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'0.08 Related Business Cases ', N'<w:alias w:val="0.08 Related Business Cases "/>', N'', N'', 1, 8)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'0.09 Departments Priority Ranking', N'<w:alias w:val="0.09 Departments Priority Ranking"/>', N'', N'', 1, 9)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'0.10 ET Business Case Approval Date ', N'<w:alias w:val="0.10 ET Business Case Approval Date "/>', N'', N'', 1, 10)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'0.11 Portfolio Recommendation ', N'<w:alias w:val="0.11 Portfolio Recommendation "/>', N'<w:t xml:space="preserve">Corporate Planning Recommendation </w:t></w:r></w:p>', N'AND [Column 0] LIKE ''<w:t>%''', 1, 11)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'0.12 Corporate Planning Recommendation ', N'<w:alias w:val="0.12 Corporate Planning Recommendation "/>', N'<w:t>Table of Contents</w:t></w:r></w:p>', N'AND [Column 0] LIKE ''<w:t>%</w:t></w:r></w:p></w:tc></w:sdtContent></w:sdt></w:tr></w:tbl>''', 1, 12)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'0.13 Executive Summary', N'<w:alias w:val="0.13 Executive Summary"/>', N'<w:t>High Level Business Case</w:t></w:r>', N'AND ([Column 0] LIKE ''<w:t>%'' OR [Column 0] LIKE ''<w:t xml:space="preserve">%'' )', 1, 13)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.1.1 What problems or opportunities ', N'<w:alias w:val="1.1.1 What problems or opportunities "/>', N'<w:t>What will this business case accomplish?</w:t></w:r></w:p></w:tc></w:tr>', N'AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:p>%'' ) ', 1, 14)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.1.1 What problems or opportunities ', N'<w:alias w:val="1.1.1 What problems or opportunities "/>', N'', N'', 0, 15)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.1.2 What will this business case accomplish', N'<w:alias w:val="1.1.2 What will this business case accomplish"/>', N'<w:alias w:val="1.1.3 Identify the internal and external drivers "/>', N'AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:sdtContent></w:sdt></w:p></w:sdtContent></w:sdt>'' ) ', 1, 16)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.1.3 Identify the internal and external drivers ', N'<w:alias w:val="1.1.3 Identify the internal and external drivers "/>', N'<w:alias w:val="1.1.4 Estimated Completion Date "/>', N' AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:p>%'' AND id<(SELECT TOP 1 ID FROM [Sandbox].[dbo].[File] WHERE [Column 0] LIKE ''<w:t>What is the expected duration of this business case</w:t></w:r>'')) ', 1, 17)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.1.4 Estimated Completion Date ', N'<w:alias w:val="1.1.4 Estimated Completion Date "/>', N'<w:alias w:val="1.2.1 What are the key work activities "/>', N'AND ([Column 0] LIKE ''<w:date w:fullDate="%">'' ) ', 1, 18)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.1.4 Estimated Start Date', N'<w:alias w:val="1.1.4 Estimated Start Date"/>', N'<w:alias w:val="1.1.4 Estimated Completion Date "/>', N'AND ([Column 0] LIKE ''<w:date w:fullDate="%">'' ) ', 1, 19)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.2.1 What are the key work activities ', N'<w:alias w:val="1.2.1 What are the key work activities "/>', N'', N'', 1, 20)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.2.2 Organizational Impact', N'<w:alias w:val="1.2.2 Organizational Impact"/>', NULL, NULL, 0, 21)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.2.3 Please list the departments from 1.2.2 ', N'<w:alias w:val="1.2.3 Please list the departments from 1.2.2 "/>', N'', N'', 1, 22)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.2.4 What are other viable alternatives ', N'<w:alias w:val="1.2.4 What are other viable alternatives "/>', N'', N'', 1, 23)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.2.5 What is the level of impact', N'<w:alias w:val="1.2.5 What is the level of impact"/>', N'', N'', 1, 24)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.1 Goal 1: Build strong communities to support the diverse ', N'<w:alias w:val="1.3.1.1 Goal 1: Build strong communities to support the diverse "/>', N'<w:alias w:val="1.3.1.1.1 Opportunities for meaningful connections within commun"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 25)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.1.1 Opportunities for meaningful connections within commun', N'<w:alias w:val="1.3.1.1.1 Opportunities for meaningful connections within commun"/>', N'<w:alias w:val="1.3.1.1.2 Diverse and inclusive communities"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 26)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.1.2 Diverse and inclusive communities', N'<w:alias w:val="1.3.1.1.2 Diverse and inclusive communities"/>', N'<w:alias w:val="1.3.1.1.3 Appropriate access to the social service system throug"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 27)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.1.3 Appropriate access to the social service system throug', N'<w:alias w:val="1.3.1.1.3 Appropriate access to the social service system throug"/>', N'<w:alias w:val="1.3.1.1.4 Affordable basic municipal services"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 28)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.1.4 Affordable basic municipal services', N'<w:alias w:val="1.3.1.1.4 Affordable basic municipal services"/>', N'<w:alias w:val="1.3.1.1.5 Programming meets the changing needs of residents"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 29)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.1.5 Programming meets the changing needs of residents', N'<w:alias w:val="1.3.1.1.5 Programming meets the changing needs of residents"/>', N'<w:alias w:val="1.3.1.1.6 Opportunities to be healthy and active"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 30)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.1.6 Opportunities to be healthy and active', N'<w:alias w:val="1.3.1.1.6 Opportunities to be healthy and active"/>', N'<w:alias w:val="1.3.1.2 Goal 2: Manage, invest and plan for sustainable municipa"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 31)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.2 Goal 2: Manage, invest and plan for sustainable municipa', N'<w:alias w:val="1.3.1.2 Goal 2: Manage, invest and plan for sustainable municipa"/>', N'<w:alias w:val="1.3.1.2.1 Efficient and effective multi-modal transportation net"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 32)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.2.1 Efficient and effective multi-modal transportation net', N'<w:alias w:val="1.3.1.2.1 Efficient and effective multi-modal transportation net"/>', N'<w:alias w:val="1.3.1.2.2 Safe, reliable utility infrastructure"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 33)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.2.2 Safe, reliable utility infrastructure', N'<w:alias w:val="1.3.1.2.2 Safe, reliable utility infrastructure"/>', N'<w:alias w:val="1.3.1.2.3 Innovative smart infrastructure"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 34)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.2.3 Innovative smart infrastructure', N'<w:alias w:val="1.3.1.2.3 Innovative smart infrastructure"/>', N'<w:alias w:val="1.3.1.2.4 Accessible cultural, recreational and social infrastru"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 35)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.2.4 Accessible cultural, recreational and social infrastru', N'<w:alias w:val="1.3.1.2.4 Accessible cultural, recreational and social infrastru"/>', N'<w:alias w:val="1.3.1.2.5 Accessible, reliable internet connectivity"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 36)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.2.5 Accessible, reliable internet connectivity', N'<w:alias w:val="1.3.1.2.5 Accessible, reliable internet connectivity"/>', N'<w:alias w:val="1.3.1.2.6 Partnerships enhance  infrastructure investment opport"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 37)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.2.6 Partnerships enhance  infrastructure investment opport', N'<w:alias w:val="1.3.1.2.6 Partnerships enhance  infrastructure investment opport"/>', N'<w:alias w:val="1.3.1.3 Goal 3: Cultivate economic diversification, within the p"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 38)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.3 Goal 3: Cultivate economic diversification, within the p', N'<w:alias w:val="1.3.1.3 Goal 3: Cultivate economic diversification, within the p"/>', N'<w:alias w:val="1.3.1.3.1 Strategic partnerships promote business growth and ret"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 39)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.3.1 Strategic partnerships promote business growth and ret', N'<w:alias w:val="1.3.1.3.1 Strategic partnerships promote business growth and ret"/>', N'<w:alias w:val="1.3.1.3.2 Planning supports strategic development"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 40)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.3.2 Planning supports strategic development', N'<w:alias w:val="1.3.1.3.2 Planning supports strategic development"/>', N'<w:alias w:val="1.3.1.3.3 Critical physical and technology infrastructure suppor"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 41)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.3.3 Critical physical and technology infrastructure suppor', N'<w:alias w:val="1.3.1.3.3 Critical physical and technology infrastructure suppor"/>', N'<w:alias w:val="1.3.1.3.4 Investment attraction and retention focus on downstrea"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 42)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.3.4 Investment attraction and retention focus on downstrea', N'<w:alias w:val="1.3.1.3.4 Investment attraction and retention focus on downstrea"/>', N'<w:alias w:val="1.3.1.3.5 Strengths and innovation as a competitive advantage su"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 43)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.3.5 Strengths and innovation as a competitive advantage su', N'<w:alias w:val="1.3.1.3.5 Strengths and innovation as a competitive advantage su"/>', N'<w:alias w:val="1.3.1.3.6 Growth opportunities  increase through regional brand "/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 44)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.3.6 Growth opportunities  increase through regional brand ', N'<w:alias w:val="1.3.1.3.6 Growth opportunities  increase through regional brand "/>', N'<w:alias w:val="1.3.1.4 Goal 4: Ensure effective stewardship of water, land, air"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 45)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.4 Goal 4: Ensure effective stewardship of water, land, air', N'<w:alias w:val="1.3.1.4 Goal 4: Ensure effective stewardship of water, land, air"/>', N'<w:alias w:val="1.3.1.4.1 Appropriate and effective use of agricultural land"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 46)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.4.1 Appropriate and effective use of agricultural land', N'<w:alias w:val="1.3.1.4.1 Appropriate and effective use of agricultural land"/>', N'<w:alias w:val="1.3.1.4.2 Natural areas and resources balance value for current "/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 47)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.4.2 Natural areas and resources balance value for current ', N'<w:alias w:val="1.3.1.4.2 Natural areas and resources balance value for current "/>', N'<w:alias w:val="1.3.1.4.3 Municipal buildings deploy efficient technology where "/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 48)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.4.3 Municipal buildings deploy efficient technology where ', N'<w:alias w:val="1.3.1.4.3 Municipal buildings deploy efficient technology where "/>', N'<w:alias w:val="1.3.1.4.4 Growth and development  balanced with recognition and "/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 49)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.4.4 Growth and development  balanced with recognition and ', N'<w:alias w:val="1.3.1.4.4 Growth and development  balanced with recognition and "/>', N'<w:alias w:val="1.3.1.4.5 County uses best practice approach to waste management"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 50)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.4.5 County uses best practice approach to waste management', N'<w:alias w:val="1.3.1.4.5 County uses best practice approach to waste management"/>', N'<w:alias w:val="1.3.1.5 Goal 5: Foster collaboration through regional, community"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 51)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.5 Goal 5: Foster collaboration through regional, community', N'<w:alias w:val="1.3.1.5 Goal 5: Foster collaboration through regional, community"/>', N'<w:alias w:val="1.3.1.5.1 Improved regional land use and resource management pla"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 52)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.5.1 Improved regional land use and resource management pla', N'<w:alias w:val="1.3.1.5.1 Improved regional land use and resource management pla"/>', N'<w:alias w:val="1.3.1.5.2 Regional assets leveraged for mutual benefit"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 53)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.5.2 Regional assets leveraged for mutual benefit', N'<w:alias w:val="1.3.1.5.2 Regional assets leveraged for mutual benefit"/>', N'<w:alias w:val="1.3.1.5.3 Innovation and lifelong learning opportunities occur t"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 54)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.5.3 Innovation and lifelong learning opportunities occur t', N'<w:alias w:val="1.3.1.5.3 Innovation and lifelong learning opportunities occur t"/>', N'<w:alias w:val="1.3.1.5.4 Community partnerships leveraged to expand the County"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 55)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.5.4 Community partnerships leveraged to expand the County', N'<w:alias w:val="1.3.1.5.4 Community partnerships leveraged to expand the County"/>', NULL, NULL, 0, 56)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.6 Goal 6: Provide facilities and services that are availab', N'<w:alias w:val="1.3.1.6 Goal 6: Provide facilities and services that are availab"/>', N'<w:alias w:val="1.3.1.6.1 Connected, accessible multi-modal transportation netwo"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 57)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.6.1 Connected, accessible multi-modal transportation netwo', N'<w:alias w:val="1.3.1.6.1 Connected, accessible multi-modal transportation netwo"/>', N'<w:alias w:val="1.3.1.6.2 Available, accessible and affordable recreational oppo"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 58)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.6.2 Available, accessible and affordable recreational oppo', N'<w:alias w:val="1.3.1.6.2 Available, accessible and affordable recreational oppo"/>', N'<w:alias w:val="1.3.1.6.3 Diverse, affordable neighbourhoods, amenities and hous"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 59)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.6.3 Diverse, affordable neighbourhoods, amenities and hous', N'<w:alias w:val="1.3.1.6.3 Diverse, affordable neighbourhoods, amenities and hous"/>', N'<w:alias w:val="1.3.1.6.4 Enhanced community interaction and connectedness"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 60)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.6.4 Enhanced community interaction and connectedness', N'<w:alias w:val="1.3.1.6.4 Enhanced community interaction and connectedness"/>', N'<w:alias w:val="1.3.1.6.5 Accessible community and cultural events; and entertai"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 61)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.6.5 Accessible community and cultural events; and entertai', N'<w:alias w:val="1.3.1.6.5 Accessible community and cultural events; and entertai"/>', N'<w:alias w:val="1.3.1.7 Goal 7: Provide opportunities for public engagement and "/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 62)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.7 Goal 7: Provide opportunities for public engagement and ', N'<w:alias w:val="1.3.1.7 Goal 7: Provide opportunities for public engagement and "/>', N'<w:alias w:val="1.3.1.7.1 Community is informed about County decisions"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 63)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.7.1 Community is informed about County decisions', N'<w:alias w:val="1.3.1.7.1 Community is informed about County decisions"/>', N'<w:alias w:val="1.3.1.7.2 Community is satisfied with opportunities to provide i"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 64)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.7.2 Community is satisfied with opportunities to provide i', N'<w:alias w:val="1.3.1.7.2 Community is satisfied with opportunities to provide i"/>', N'<w:alias w:val="1.3.1.7.3 Community is confident in how tax dollars are managed"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 65)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.7.3 Community is confident in how tax dollars are managed', N'<w:alias w:val="1.3.1.7.3 Community is confident in how tax dollars are managed"/>', N'<w:alias w:val="1.3.1.7.4 Public engagement efforts and information sharing mech"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 66)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.7.4 Public engagement efforts and information sharing mech', N'<w:alias w:val="1.3.1.7.4 Public engagement efforts and information sharing mech"/>', N'<w:alias w:val="1.3.1.8 Goal 8: Foster an environment for safe communities"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 67)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.8 Goal 8: Foster an environment for safe communities', N'<w:alias w:val="1.3.1.8 Goal 8: Foster an environment for safe communities"/>', N'<w:alias w:val="1.3.1.8.1 Law enforcement, emergency and social services respond"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 68)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.8.1 Law enforcement, emergency and social services respond', N'<w:alias w:val="1.3.1.8.1 Law enforcement, emergency and social services respond"/>', N'<w:alias w:val="1.3.1.8.2 Proactive safety education and community involvement"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 69)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.8.2 Proactive safety education and community involvement', N'<w:alias w:val="1.3.1.8.2 Proactive safety education and community involvement"/>', N'<w:alias w:val="1.3.1.8.3 Utility infrastructure provides safe, clean water; man"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 70)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.8.3 Utility infrastructure provides safe, clean water; man', N'<w:alias w:val="1.3.1.8.3 Utility infrastructure provides safe, clean water; man"/>', N'<w:alias w:val="1.3.1.8.4 Citizens feel safe to express themselves in ways that "/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 71)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.8.4 Citizens feel safe to express themselves in ways that ', N'<w:alias w:val="1.3.1.8.4 Citizens feel safe to express themselves in ways that "/>', N'<w:alias w:val="1.3.1.8.5 Transportation network, including trails, allows peopl"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 72)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.8.5 Transportation network, including trails, allows peopl', N'<w:alias w:val="1.3.1.8.5 Transportation network, including trails, allows peopl"/>', N'<w:alias w:val="1.3.1.9 Organizational Excellence Goal"/>', N'AND ([Column 0] LIKE ''%<w14:checkbox><w14:checked w14:val="%"/><%'' )', 1, 73)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.9 Organizational Excellence Goal', N'<w:alias w:val="1.3.1.9 Organizational Excellence Goal"/>', NULL, NULL, 0, 74)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.9.1 Collaborates with regional, community and government p', N'<w:alias w:val="1.3.1.9.1 Collaborates with regional, community and government p"/>', NULL, NULL, 0, 75)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.9.10 Supports integrated planning', N'<w:alias w:val="1.3.1.9.10 Supports integrated planning"/>', NULL, NULL, 0, 76)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.9.11 Leverages tools (i.e. technology, equipment) to assis', N'<w:alias w:val="1.3.1.9.11 Leverages tools (i.e. technology, equipment) to assis"/>', NULL, NULL, 0, 77)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.9.12 Engages stakeholders in decision making', N'<w:alias w:val="1.3.1.9.12 Engages stakeholders in decision making"/>', NULL, NULL, 0, 78)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.9.13 Communicates to stakeholders about County programs an', N'<w:alias w:val="1.3.1.9.13 Communicates to stakeholders about County programs an"/>', NULL, NULL, 0, 79)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.9.14 Collaborates with departments', N'<w:alias w:val="1.3.1.9.14 Collaborates with departments"/>', NULL, NULL, 0, 80)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.9.2 Integrates information and technology', N'<w:alias w:val="1.3.1.9.2 Integrates information and technology"/>', NULL, NULL, 0, 81)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.9.3 Supports long term financial sustainability', N'<w:alias w:val="1.3.1.9.3 Supports long term financial sustainability"/>', NULL, NULL, 0, 82)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.9.4 Supports infrastructure management  ', N'<w:alias w:val="1.3.1.9.4 Supports infrastructure management  "/>', NULL, NULL, 0, 83)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.9.5 Supports workplace culture that builds trust and promo', N'<w:alias w:val="1.3.1.9.5 Supports workplace culture that builds trust and promo"/>', NULL, NULL, 0, 84)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.9.6 Supports development of employee capacity through trai', N'<w:alias w:val="1.3.1.9.6 Supports development of employee capacity through trai"/>', NULL, NULL, 0, 85)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.9.7 Supports insight-driven evidence-based decision making', N'<w:alias w:val="1.3.1.9.7 Supports insight-driven evidence-based decision making"/>', NULL, NULL, 0, 86)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.9.8 Supports continuous improvement', N'<w:alias w:val="1.3.1.9.8 Supports continuous improvement"/>', NULL, NULL, 0, 87)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.1.9.9 Ensures compliance with regulations, laws, procedures ', N'<w:alias w:val="1.3.1.9.9 Ensures compliance with regulations, laws, procedures "/>', NULL, NULL, 0, 88)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.2 Alignment with Strategic/Governance Results', N'<w:alias w:val="1.3.2 Alignment with Strategic/Governance Results"/>', NULL, NULL, 0, 89)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.3 Program Mandate', N'<w:alias w:val="1.3.3 Program Mandate"/>', NULL, NULL, 0, 90)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.4 Portion of Community/Organization Served', N'<w:alias w:val="1.3.4 Portion of Community/Organization Served"/>', NULL, NULL, 0, 91)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.5 Business Value', N'<w:alias w:val="1.3.5 Business Value"/>', NULL, NULL, 0, 92)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'1.3.6 Time to Value after Completion', N'<w:alias w:val="1.3.6 Time to Value after Completion"/>', NULL, NULL, 0, 93)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.3.2019.Annual Operating', N'<w:alias w:val="2.3.2019.Annual Operating"/>', N'<w:alias w:val="2.3.2020.Annual Operating"/>', N'AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:p></w:sdtContent></w:sdt>'' )', 1, 94)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.3.2019.Upfront Investment', N'<w:alias w:val="2.3.2019.Upfront Investment"/>', N'<w:alias w:val="2.3.2020.Upfront Investment"/>', N'AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:p></w:sdtContent></w:sdt>'' )', 1, 95)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.3.2020.Annual Operating', N'<w:alias w:val="2.3.2020.Annual Operating"/>', N'<w:alias w:val="2.3.2021.Annual Operating"/>', N'AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:p></w:sdtContent></w:sdt>'' )', 1, 96)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.3.2020.Upfront Investment', N'<w:alias w:val="2.3.2020.Upfront Investment"/>', N'<w:alias w:val="2.3.2021.Upfront Investment"/>', N'AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:p></w:sdtContent></w:sdt>'' )', 1, 97)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.3.2021.Annual Operating', N'<w:alias w:val="2.3.2021.Annual Operating"/>', N'<w:alias w:val="2.3.2022.Annual Operating"/>', N'AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:p></w:sdtContent></w:sdt>'' )', 1, 98)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.3.2021.Upfront Investment', N'<w:alias w:val="2.3.2021.Upfront Investment"/>', N'<w:alias w:val="2.3.2022.Upfront Investment"/>', N'AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:p></w:sdtContent></w:sdt>'' )', 1, 99)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.3.2022.Annual Operating', N'<w:alias w:val="2.3.2022.Annual Operating"/>', N'<w:alias w:val="2.3.2023.Annual Operating"/>', N'AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:p></w:sdtContent></w:sdt>'' )', 1, 100)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.3.2022.Upfront Investment', N'<w:alias w:val="2.3.2022.Upfront Investment"/>', N'<w:alias w:val="2.3.2023.Upfront Investment"/>', N'AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:p></w:sdtContent></w:sdt>'' )', 1, 101)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.3.2023.Annual Operating', N'<w:alias w:val="2.3.2023.Annual Operating"/>', N'<w:alias w:val="2.3.2024.Annual Operating"/>', N'AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:p></w:sdtContent></w:sdt>'' )', 1, 102)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.3.2023.Upfront Investment', N'<w:alias w:val="2.3.2023.Upfront Investment"/>', N'<w:alias w:val="2.3.2024.Upfront Investment"/>', N'AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:p></w:sdtContent></w:sdt>'' )', 1, 103)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.3.2024.Annual Operating', N'<w:alias w:val="2.3.2024.Annual Operating"/>', N'<w:alias w:val="2.3.Total.Annual Operating"/>', N'AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:p></w:sdtContent></w:sdt>'' )', 1, 104)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.3.2024.Upfront Investment', N'<w:alias w:val="2.3.2024.Upfront Investment"/>', N'<w:alias w:val="2.3.Total.Upfront Investment"/>', N'AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:p></w:sdtContent></w:sdt>'' )', 1, 105)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.3.Total.Annual Operating', N'<w:alias w:val="2.3.Total.Annual Operating"/>', N'<w:alias w:val="2.4. What are the estimated resources required "/>', N'AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:p></w:sdtContent></w:sdt>'' )', 1, 106)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.3.Total.Upfront Investment', N'<w:alias w:val="2.3.Total.Upfront Investment"/>', N'<w:alias w:val="2.3.2019.Annual Operating"/>', N'AND ([Column 0] LIKE ''<w:t>%</w:t></w:r></w:p></w:sdtContent></w:sdt>'' )', 1, 107)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.4. What are the estimated resources required ', N'<w:alias w:val="2.4. What are the estimated resources required "/>', N'', N'', 1, 108)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.5 If applicable, are there any other future maintenance', N'<w:alias w:val="2.5 If applicable, are there any other future maintenance"/>', N'', N'', 1, 109)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'2.6 Cost Recovery', N'<w:alias w:val="2.6 Cost Recovery"/>', NULL, NULL, 0, 110)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'3.1 Solution Complexity', N'<w:alias w:val="3.1 Solution Complexity"/>', NULL, NULL, 0, 111)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'3.2 Resource &amp; Capacity Impact', N'<w:alias w:val="3.2 Resource &amp; Capacity Impact"/>', NULL, NULL, 0, 112)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'3.3 Degree of change', N'<w:alias w:val="3.3 Degree of change"/>', NULL, NULL, 0, 113)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'3.4 Reliance to Provide', N'<w:alias w:val="3.4 Reliance to Provide"/>', NULL, NULL, 0, 114)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.1.1 What is the relevant history', N'<w:alias w:val="4.1.1 What is the relevant history"/>', N'', N'', 1, 115)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.1 What quantitative and/or qualitative measures ', N'<w:alias w:val="4.2.1 What quantitative and/or qualitative measures "/>', N'', N'', 1, 116)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.1 Core', N'<w:alias w:val="4.2.2.1 Core"/>', N'', N'', 1, 117)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.1 Desirable', N'<w:alias w:val="4.2.2.1 Desirable"/>', N'', N'', 1, 118)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.1 Optional', N'<w:alias w:val="4.2.2.1 Optional"/>', N'', N'', 1, 119)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.1 Requirement Description', N'<w:alias w:val="4.2.2.1 Requirement Description"/>', N'', N'', 1, 120)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.2 Core', N'<w:alias w:val="4.2.2.2 Core"/>', N'', N'', 1, 121)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.2 Desirable', N'<w:alias w:val="4.2.2.2 Desirable"/>', N'', N'', 1, 122)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.2 Optional', N'<w:alias w:val="4.2.2.2 Optional"/>', N'', N'', 1, 123)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.2 Requirement Description', N'<w:alias w:val="4.2.2.2 Requirement Description"/>', N'', N'', 1, 124)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.3 Core', N'<w:alias w:val="4.2.2.3 Core"/>', N'', N'', 1, 125)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.3 Desirable', N'<w:alias w:val="4.2.2.3 Desirable"/>', N'', N'', 1, 126)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.3 Optional', N'<w:alias w:val="4.2.2.3 Optional"/>', N'', N'', 1, 127)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.3 Requirement Description', N'<w:alias w:val="4.2.2.3 Requirement Description"/>', N'', N'', 1, 128)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.4 Core', N'<w:alias w:val="4.2.2.4 Core"/>', N'', N'', 1, 129)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.4 Desirable', N'<w:alias w:val="4.2.2.4 Desirable"/>', N'', N'', 1, 130)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.4 Optional', N'<w:alias w:val="4.2.2.4 Optional"/>', N'', N'', 1, 131)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.4 Requirement Description', N'<w:alias w:val="4.2.2.4 Requirement Description"/>', N'', N'', 1, 132)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.5 Core', N'<w:alias w:val="4.2.2.5 Core"/>', N'', N'', 1, 133)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.5 Desirable', N'<w:alias w:val="4.2.2.5 Desirable"/>', N'', N'', 1, 134)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.5 Optional', N'<w:alias w:val="4.2.2.5 Optional"/>', N'', N'', 1, 135)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.2.5 Requirement Description', N'<w:alias w:val="4.2.2.5 Requirement Description"/>', N'', N'', 1, 136)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.3 Is there anything relevant to note that is excluded', N'<w:alias w:val="4.2.3 Is there anything relevant to note that is excluded"/>', N'', N'', 1, 137)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.4 Are there any additional outcomes', N'<w:alias w:val="4.2.4 Are there any additional outcomes"/>', N'', N'', 1, 138)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.5 What are the specific deliverables', N'<w:alias w:val="4.2.5 What are the specific deliverables"/>', N'', N'', 1, 139)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.1 Core', N'<w:alias w:val="4.2.6.1 Core"/>', N'', N'', 1, 140)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.1 Desirable', N'<w:alias w:val="4.2.6.1 Desirable"/>', N'', N'', 1, 141)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.1 Optional', N'<w:alias w:val="4.2.6.1 Optional"/>', N'', N'', 1, 142)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.1 Requirement Description', N'<w:alias w:val="4.2.6.1 Requirement Description"/>', N'', N'', 1, 143)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.2 Core', N'<w:alias w:val="4.2.6.2 Core"/>', N'', N'', 1, 144)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.2 Desirable', N'<w:alias w:val="4.2.6.2 Desirable"/>', N'', N'', 1, 145)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.2 Optional', N'<w:alias w:val="4.2.6.2 Optional"/>', N'', N'', 1, 146)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.2 Requirement Description', N'<w:alias w:val="4.2.6.2 Requirement Description"/>', N'', N'', 1, 147)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.3 Core', N'<w:alias w:val="4.2.6.3 Core"/>', N'', N'', 1, 148)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.3 Desirable', N'<w:alias w:val="4.2.6.3 Desirable"/>', N'', N'', 1, 149)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.3 Optional', N'<w:alias w:val="4.2.6.3 Optional"/>', N'', N'', 1, 150)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.3 Requirement Description', N'<w:alias w:val="4.2.6.3 Requirement Description"/>', N'', N'', 1, 151)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.4 Core', N'<w:alias w:val="4.2.6.4 Core"/>', N'', N'', 1, 152)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.4 Desirable', N'<w:alias w:val="4.2.6.4 Desirable"/>', N'', N'', 1, 153)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.4 Optional', N'<w:alias w:val="4.2.6.4 Optional"/>', N'', N'', 1, 154)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.4 Requirement Description', N'<w:alias w:val="4.2.6.4 Requirement Description"/>', N'', N'', 1, 155)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.5 Core', N'<w:alias w:val="4.2.6.5 Core"/>', N'', N'', 1, 156)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.5 Desirable', N'<w:alias w:val="4.2.6.5 Desirable"/>', N'', N'', 1, 157)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.5 Optional', N'<w:alias w:val="4.2.6.5 Optional"/>', N'', N'', 1, 158)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'4.2.6.5 Requirement Description', N'<w:alias w:val="4.2.6.5 Requirement Description"/>', N'', N'', 1, 159)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.1 Deliverable', N'<w:alias w:val="5.1.1.1 Deliverable"/>', N'', N'', 1, 160)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.1 Level of Effort', N'<w:alias w:val="5.1.1.1 Level of Effort"/>', N'', N'', 1, 161)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.1 Position', N'<w:alias w:val="5.1.1.1 Position"/>', N'', N'', 1, 162)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.1 Skill Description', N'<w:alias w:val="5.1.1.1 Skill Description"/>', N'', N'', 1, 163)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.2 Deliverable', N'<w:alias w:val="5.1.1.2 Deliverable"/>', N'', N'', 1, 164)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.2 Level of Effort', N'<w:alias w:val="5.1.1.2 Level of Effort"/>', N'', N'', 1, 165)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.2 Position', N'<w:alias w:val="5.1.1.2 Position"/>', N'', N'', 1, 166)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.2 Skill Description', N'<w:alias w:val="5.1.1.2 Skill Description"/>', N'', N'', 1, 167)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.3 Deliverable', N'<w:alias w:val="5.1.1.3 Deliverable"/>', N'', N'', 1, 168)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.3 Level of Effort', N'<w:alias w:val="5.1.1.3 Level of Effort"/>', N'', N'', 1, 169)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.3 Position', N'<w:alias w:val="5.1.1.3 Position"/>', N'', N'', 1, 170)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.3 Skill Description', N'<w:alias w:val="5.1.1.3 Skill Description"/>', N'', N'', 1, 171)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.4 Deliverable', N'<w:alias w:val="5.1.1.4 Deliverable"/>', N'', N'', 1, 172)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.4 Level of Effort', N'<w:alias w:val="5.1.1.4 Level of Effort"/>', N'', N'', 1, 173)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.4 Position', N'<w:alias w:val="5.1.1.4 Position"/>', N'', N'', 1, 174)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.4 Skill Description', N'<w:alias w:val="5.1.1.4 Skill Description"/>', N'', N'', 1, 175)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.5 Deliverable', N'<w:alias w:val="5.1.1.5 Deliverable"/>', N'', N'', 1, 176)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.5 Level of Effort', N'<w:alias w:val="5.1.1.5 Level of Effort"/>', N'', N'', 1, 177)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.5 Position', N'<w:alias w:val="5.1.1.5 Position"/>', N'', N'', 1, 178)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.1.5 Skill Description', N'<w:alias w:val="5.1.1.5 Skill Description"/>', N'', N'', 1, 179)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.1 Deliverable', N'<w:alias w:val="5.1.2.1 Deliverable"/>', N'', N'', 1, 180)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.1 Level of Effort', N'<w:alias w:val="5.1.2.1 Level of Effort"/>', N'', N'', 1, 181)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.1 Position', N'<w:alias w:val="5.1.2.1 Position"/>', N'', N'', 1, 182)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.1 Skill Description', N'<w:alias w:val="5.1.2.1 Skill Description"/>', N'', N'', 1, 183)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.2 Deliverable', N'<w:alias w:val="5.1.2.2 Deliverable"/>', N'', N'', 1, 184)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.2 Level of Effort', N'<w:alias w:val="5.1.2.2 Level of Effort"/>', N'', N'', 1, 185)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.2 Position', N'<w:alias w:val="5.1.2.2 Position"/>', N'', N'', 1, 186)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.2 Skill Description', N'<w:alias w:val="5.1.2.2 Skill Description"/>', N'', N'', 1, 187)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.3 Deliverable', N'<w:alias w:val="5.1.2.3 Deliverable"/>', N'', N'', 1, 188)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.3 Level of Effort', N'<w:alias w:val="5.1.2.3 Level of Effort"/>', N'', N'', 1, 189)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.3 Position', N'<w:alias w:val="5.1.2.3 Position"/>', N'', N'', 1, 190)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.3 Skill Description', N'<w:alias w:val="5.1.2.3 Skill Description"/>', N'', N'', 1, 191)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.4 Deliverable', N'<w:alias w:val="5.1.2.4 Deliverable"/>', N'', N'', 1, 192)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.4 Level of Effort', N'<w:alias w:val="5.1.2.4 Level of Effort"/>', N'', N'', 1, 193)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.4 Position', N'<w:alias w:val="5.1.2.4 Position"/>', N'', N'', 1, 194)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.4 Skill Description', N'<w:alias w:val="5.1.2.4 Skill Description"/>', N'', N'', 1, 195)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.5 Deliverable', N'<w:alias w:val="5.1.2.5 Deliverable"/>', N'', N'', 1, 196)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.5 Level of Effort', N'<w:alias w:val="5.1.2.5 Level of Effort"/>', N'', N'', 1, 197)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.5 Position', N'<w:alias w:val="5.1.2.5 Position"/>', N'', N'', 1, 198)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.2.5 Skill Description', N'<w:alias w:val="5.1.2.5 Skill Description"/>', N'', N'', 1, 199)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.1 Deliverable', N'<w:alias w:val="5.1.3.1 Deliverable"/>', N'', N'', 1, 200)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.1 Level of Effort', N'<w:alias w:val="5.1.3.1 Level of Effort"/>', N'', N'', 1, 201)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.1 Resource', N'<w:alias w:val="5.1.3.1 Resource"/>', N'', N'', 1, 202)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.1 Resource Description', N'<w:alias w:val="5.1.3.1 Resource Description"/>', N'', N'', 1, 203)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.2 Deliverable', N'<w:alias w:val="5.1.3.2 Deliverable"/>', N'', N'', 1, 204)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.2 Level of Effort', N'<w:alias w:val="5.1.3.2 Level of Effort"/>', N'', N'', 1, 205)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.2 Resource', N'<w:alias w:val="5.1.3.2 Resource"/>', N'', N'', 1, 206)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.2 Resource Description', N'<w:alias w:val="5.1.3.2 Resource Description"/>', N'', N'', 1, 207)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.3 Deliverable', N'<w:alias w:val="5.1.3.3 Deliverable"/>', N'', N'', 1, 208)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.3 Level of Effort', N'<w:alias w:val="5.1.3.3 Level of Effort"/>', N'', N'', 1, 209)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.3 Resource', N'<w:alias w:val="5.1.3.3 Resource"/>', N'', N'', 1, 210)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.3 Resource Description', N'<w:alias w:val="5.1.3.3 Resource Description"/>', N'', N'', 1, 211)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.4 Deliverable', N'<w:alias w:val="5.1.3.4 Deliverable"/>', N'', N'', 1, 212)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.4 Level of Effort', N'<w:alias w:val="5.1.3.4 Level of Effort"/>', N'', N'', 1, 213)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.4 Resource', N'<w:alias w:val="5.1.3.4 Resource"/>', N'', N'', 1, 214)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.4 Resource Description', N'<w:alias w:val="5.1.3.4 Resource Description"/>', N'', N'', 1, 215)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.5 Deliverable', N'<w:alias w:val="5.1.3.5 Deliverable"/>', N'', N'', 1, 216)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.5 Level of Effort', N'<w:alias w:val="5.1.3.5 Level of Effort"/>', N'', N'', 1, 217)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.5 Resource', N'<w:alias w:val="5.1.3.5 Resource"/>', N'', N'', 1, 218)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.3.5 Resource Description', N'<w:alias w:val="5.1.3.5 Resource Description"/>', N'', N'', 1, 219)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.4.1 Deliverable', N'<w:alias w:val="5.1.4.1 Deliverable"/>', N'', N'', 1, 220)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.4.1 Duration', N'<w:alias w:val="5.1.4.1 Duration"/>', N'', N'', 1, 221)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.4.1 Resource', N'<w:alias w:val="5.1.4.1 Resource"/>', N'', N'', 1, 222)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.4.1 Resource Description', N'<w:alias w:val="5.1.4.1 Resource Description"/>', N'', N'', 1, 223)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.4.2 Deliverable', N'<w:alias w:val="5.1.4.2 Deliverable"/>', N'', N'', 1, 224)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.4.2 Duration', N'<w:alias w:val="5.1.4.2 Duration"/>', N'', N'', 1, 225)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.4.2 Resource', N'<w:alias w:val="5.1.4.2 Resource"/>', N'', N'', 1, 226)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.4.2 Resource Description', N'<w:alias w:val="5.1.4.2 Resource Description"/>', N'', N'', 1, 227)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.4.3 Deliverable', N'<w:alias w:val="5.1.4.3 Deliverable"/>', N'', N'', 1, 228)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.4.3 Duration', N'<w:alias w:val="5.1.4.3 Duration"/>', N'', N'', 1, 229)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.4.3 Resource', N'<w:alias w:val="5.1.4.3 Resource"/>', N'', N'', 1, 230)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.4.3 Resource Description', N'<w:alias w:val="5.1.4.3 Resource Description"/>', N'', N'', 1, 231)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.4.4 Deliverable', N'<w:alias w:val="5.1.4.4 Deliverable"/>', N'', N'', 1, 232)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.4.4 Duration', N'<w:alias w:val="5.1.4.4 Duration"/>', N'', N'', 1, 233)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.4.4 Resource', N'<w:alias w:val="5.1.4.4 Resource"/>', N'', N'', 1, 234)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.4.4 Resource Description', N'<w:alias w:val="5.1.4.4 Resource Description"/>', N'', N'', 1, 235)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.5.5 Deliverable', N'<w:alias w:val="5.1.5.5 Deliverable"/>', N'', N'', 1, 236)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.5.5 Duration', N'<w:alias w:val="5.1.5.5 Duration"/>', N'', N'', 1, 237)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.5.5 Resource', N'<w:alias w:val="5.1.5.5 Resource"/>', N'', N'', 1, 238)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.1.5.5 Resource Description', N'<w:alias w:val="5.1.5.5 Resource Description"/>', N'', N'', 1, 239)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.2.1 Will this business case have an impact', N'<w:alias w:val="5.2.1 Will this business case have an impact"/>', N'', N'', 1, 240)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.2.2 How certain are the cost estimates?', N'<w:alias w:val="5.2.2 How certain are the cost estimates?"/>', N'', N'', 1, 241)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.2.3 Describe how significantly the future operating/ongoing', N'<w:alias w:val="5.2.3 Describe how significantly the future operating/ongoing"/>', N'', N'', 1, 242)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.2.4 How feasible is this change resulting', N'<w:alias w:val="5.2.4 How feasible is this change resulting"/>', N'', N'', 1, 243)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.2.5 What are the significant assumptions made', N'<w:alias w:val="5.2.5 What are the significant assumptions made"/>', N'', N'', 1, 244)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.1.1 Responsibility', N'<w:alias w:val="5.3.1.1 Responsibility"/>', N'', N'', 1, 245)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.1.1 Role', N'<w:alias w:val="5.3.1.1 Role"/>', N'', N'', 1, 246)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.1.1 Stakeholder Group', N'<w:alias w:val="5.3.1.1 Stakeholder Group"/>', N'', N'', 1, 247)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.1.2 Responsibility', N'<w:alias w:val="5.3.1.2 Responsibility"/>', N'', N'', 1, 248)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.1.2 Role', N'<w:alias w:val="5.3.1.2 Role"/>', N'', N'', 1, 249)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.1.2 Stakeholder Group', N'<w:alias w:val="5.3.1.2 Stakeholder Group"/>', N'', N'', 1, 250)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.1.3 Responsibility', N'<w:alias w:val="5.3.1.3 Responsibility"/>', N'', N'', 1, 251)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.1.3 Role', N'<w:alias w:val="5.3.1.3 Role"/>', N'', N'', 1, 252)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.1.3 Stakeholder Group', N'<w:alias w:val="5.3.1.3 Stakeholder Group"/>', N'', N'', 1, 253)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.1.4 Responsibility', N'<w:alias w:val="5.3.1.4 Responsibility"/>', N'', N'', 1, 254)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.1.4 Role', N'<w:alias w:val="5.3.1.4 Role"/>', N'', N'', 1, 255)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.1.4 Stakeholder Group', N'<w:alias w:val="5.3.1.4 Stakeholder Group"/>', N'', N'', 1, 256)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.1.5 Responsibility', N'<w:alias w:val="5.3.1.5 Responsibility"/>', N'', N'', 1, 257)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.1.5 Role', N'<w:alias w:val="5.3.1.5 Role"/>', N'', N'', 1, 258)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.1.5 Stakeholder Group', N'<w:alias w:val="5.3.1.5 Stakeholder Group"/>', N'', N'', 1, 259)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.2.1 Impact Description', N'<w:alias w:val="5.3.2.1 Impact Description"/>', N'', N'', 1, 260)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.2.1 Stakeholder Group', N'<w:alias w:val="5.3.2.1 Stakeholder Group"/>', N'', N'', 1, 261)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.2.2 Impact Description', N'<w:alias w:val="5.3.2.2 Impact Description"/>', N'', N'', 1, 262)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.2.2 Stakeholder Group', N'<w:alias w:val="5.3.2.2 Stakeholder Group"/>', N'', N'', 1, 263)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.2.3 Impact Description', N'<w:alias w:val="5.3.2.3 Impact Description"/>', N'', N'', 1, 264)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.2.3 Stakeholder Group', N'<w:alias w:val="5.3.2.3 Stakeholder Group"/>', N'', N'', 1, 265)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.2.4 Impact Description', N'<w:alias w:val="5.3.2.4 Impact Description"/>', N'', N'', 1, 266)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.2.4 Stakeholder Group', N'<w:alias w:val="5.3.2.4 Stakeholder Group"/>', N'', N'', 1, 267)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.2.5 Impact Description', N'<w:alias w:val="5.3.2.5 Impact Description"/>', N'', N'', 1, 268)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.2.5 Stakeholder Group', N'<w:alias w:val="5.3.2.5 Stakeholder Group"/>', N'', N'', 1, 269)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.3.1 Responsibility', N'<w:alias w:val="5.3.3.1 Responsibility"/>', N'', N'', 1, 270)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.3.1 Role', N'<w:alias w:val="5.3.3.1 Role"/>', N'', N'', 1, 271)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.3.1 Stakeholder Group', N'<w:alias w:val="5.3.3.1 Stakeholder Group"/>', N'', N'', 1, 272)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.3.2 Responsibility', N'<w:alias w:val="5.3.3.2 Responsibility"/>', N'', N'', 1, 273)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.3.2 Role', N'<w:alias w:val="5.3.3.2 Role"/>', N'', N'', 1, 274)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.3.2 Stakeholder Group', N'<w:alias w:val="5.3.3.2 Stakeholder Group"/>', N'', N'', 1, 275)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.3.3 Responsibility', N'<w:alias w:val="5.3.3.3 Responsibility"/>', N'', N'', 1, 276)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.3.3 Role', N'<w:alias w:val="5.3.3.3 Role"/>', N'', N'', 1, 277)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.3.3 Stakeholder Group', N'<w:alias w:val="5.3.3.3 Stakeholder Group"/>', N'', N'', 1, 278)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.3.4 Responsibility', N'<w:alias w:val="5.3.3.4 Responsibility"/>', N'', N'', 1, 279)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.3.4 Role', N'<w:alias w:val="5.3.3.4 Role"/>', N'', N'', 1, 280)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.3.4 Stakeholder Group', N'<w:alias w:val="5.3.3.4 Stakeholder Group"/>', N'', N'', 1, 281)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.3.5 Responsibility', N'<w:alias w:val="5.3.3.5 Responsibility"/>', N'', N'', 1, 282)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.3.5 Role', N'<w:alias w:val="5.3.3.5 Role"/>', N'', N'', 1, 283)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.3.5 Stakeholder Group', N'<w:alias w:val="5.3.3.5 Stakeholder Group"/>', N'', N'', 1, 284)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.4.1 Impact Description', N'<w:alias w:val="5.3.4.1 Impact Description"/>', N'', N'', 1, 285)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.4.1 Stakeholder Group', N'<w:alias w:val="5.3.4.1 Stakeholder Group"/>', N'', N'', 1, 286)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.4.2 Impact Description', N'<w:alias w:val="5.3.4.2 Impact Description"/>', N'', N'', 1, 287)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.4.2 Stakeholder Group', N'<w:alias w:val="5.3.4.2 Stakeholder Group"/>', N'', N'', 1, 288)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.4.3 Impact Description', N'<w:alias w:val="5.3.4.3 Impact Description"/>', N'', N'', 1, 289)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.4.3 Stakeholder Group', N'<w:alias w:val="5.3.4.3 Stakeholder Group"/>', N'', N'', 1, 290)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.4.4 Impact Description', N'<w:alias w:val="5.3.4.4 Impact Description"/>', N'', N'', 1, 291)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.4.4 Stakeholder Group', N'<w:alias w:val="5.3.4.4 Stakeholder Group"/>', N'', N'', 1, 292)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.4.5 Impact Description', N'<w:alias w:val="5.3.4.5 Impact Description"/>', N'', N'', 1, 293)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.4.5 Stakeholder Group', N'<w:alias w:val="5.3.4.5 Stakeholder Group"/>', N'', N'', 1, 294)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.5 If this business case relates to more than one Priority', N'<w:alias w:val="5.3.5 If this business case relates to more than one Priority"/>', N'', N'', 1, 295)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.6 If applicable, what is the specific impact', N'<w:alias w:val="5.3.6 If applicable, what is the specific impact"/>', N'', N'', 1, 296)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.3.7 What changes to current operations may be required', N'<w:alias w:val="5.3.7 What changes to current operations may be required"/>', N'', N'', 1, 297)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.4.1 What have other municipalities of similar size done', N'<w:alias w:val="5.4.1 What have other municipalities of similar size done"/>', N'', N'', 1, 298)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.4.2 What are other relevant industry trends and best practices', N'<w:alias w:val="5.4.2 What are other relevant industry trends and best practices"/>', N'', N'', 1, 299)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.1 Potential achievability', N'<w:alias w:val="5.5.1 Potential achievability"/>', N'', N'', 1, 300)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.1 Potential affordability', N'<w:alias w:val="5.5.1 Potential affordability"/>', N'', N'', 1, 301)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.1 Strategic fit and business needs', N'<w:alias w:val="5.5.1 Strategic fit and business needs"/>', N'', N'', 1, 302)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.1 Summary', N'<w:alias w:val="5.5.1 Summary"/>', N'', N'', 1, 303)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.2.2 Potential achievability', N'<w:alias w:val="5.5.2.2 Potential achievability"/>', N'', N'', 1, 304)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.2.2 Potential affordability', N'<w:alias w:val="5.5.2.2 Potential affordability"/>', N'', N'', 1, 305)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.2.2 Strategic fit and business needs', N'<w:alias w:val="5.5.2.2 Strategic fit and business needs"/>', N'', N'', 1, 306)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.2.2 Summary', N'<w:alias w:val="5.5.2.2 Summary"/>', N'', N'', 1, 307)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.2.3 Potential achievability', N'<w:alias w:val="5.5.2.3 Potential achievability"/>', N'', N'', 1, 308)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.2.3 Potential affordability', N'<w:alias w:val="5.5.2.3 Potential affordability"/>', N'', N'', 1, 309)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.2.3 Strategic fit and business needs', N'<w:alias w:val="5.5.2.3 Strategic fit and business needs"/>', N'', N'', 1, 310)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.2.3 Summary', N'<w:alias w:val="5.5.2.3 Summary"/>', N'', N'', 1, 311)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.2.4 Potential achievability', N'<w:alias w:val="5.5.2.4 Potential achievability"/>', N'', N'', 1, 312)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.2.4 Potential affordability', N'<w:alias w:val="5.5.2.4 Potential affordability"/>', N'', N'', 1, 313)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.2.4 Strategic fit and business needs', N'<w:alias w:val="5.5.2.4 Strategic fit and business needs"/>', N'', N'', 1, 314)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.2.4 Summary', N'<w:alias w:val="5.5.2.4 Summary"/>', N'', N'', 1, 315)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.2.5 Potential achievability', N'<w:alias w:val="5.5.2.5 Potential achievability"/>', N'', N'', 1, 316)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.2.5 Potential affordability', N'<w:alias w:val="5.5.2.5 Potential affordability"/>', N'', N'', 1, 317)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.2.5 Strategic fit and business needs', N'<w:alias w:val="5.5.2.5 Strategic fit and business needs"/>', N'', N'', 1, 318)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.2.5 Summary', N'<w:alias w:val="5.5.2.5 Summary"/>', N'', N'', 1, 319)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.3.1 Business Case Objective', N'<w:alias w:val="5.5.3.1 Business Case Objective"/>', N'', N'', 1, 320)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.3.1 Fit Description', N'<w:alias w:val="5.5.3.1 Fit Description"/>', N'', N'', 1, 321)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.3.2 Business Case Objective', N'<w:alias w:val="5.5.3.2 Business Case Objective"/>', N'', N'', 1, 322)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.3.2 Fit Description', N'<w:alias w:val="5.5.3.2 Fit Description"/>', N'', N'', 1, 323)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.3.3 Business Case Objective', N'<w:alias w:val="5.5.3.3 Business Case Objective"/>', N'', N'', 1, 324)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.3.3 Fit Description', N'<w:alias w:val="5.5.3.3 Fit Description"/>', N'', N'', 1, 325)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.3.4 Business Case Objective', N'<w:alias w:val="5.5.3.4 Business Case Objective"/>', N'', N'', 1, 326)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.3.4 Fit Description', N'<w:alias w:val="5.5.3.4 Fit Description"/>', N'', N'', 1, 327)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.3.5 Business Case Objective', N'<w:alias w:val="5.5.3.5 Business Case Objective"/>', N'', N'', 1, 328)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.3.5 Fit Description', N'<w:alias w:val="5.5.3.5 Fit Description"/>', N'', N'', 1, 329)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.4.1 Business Case Objective', N'<w:alias w:val="5.5.4.1 Business Case Objective"/>', N'', N'', 1, 330)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.4.1 Description', N'<w:alias w:val="5.5.4.1 Description"/>', N'', N'', 1, 331)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.4.2 Business Case Objective', N'<w:alias w:val="5.5.4.2 Business Case Objective"/>', N'', N'', 1, 332)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.4.2 Description', N'<w:alias w:val="5.5.4.2 Description"/>', N'', N'', 1, 333)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.4.3 Business Case Objective', N'<w:alias w:val="5.5.4.3 Business Case Objective"/>', N'', N'', 1, 334)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.4.3 Description', N'<w:alias w:val="5.5.4.3 Description"/>', N'', N'', 1, 335)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.4.4 Business Case Objective', N'<w:alias w:val="5.5.4.4 Business Case Objective"/>', N'', N'', 1, 336)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.4.4 Description', N'<w:alias w:val="5.5.4.4 Description"/>', N'', N'', 1, 337)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.4.5 Business Case Objective', N'<w:alias w:val="5.5.4.5 Business Case Objective"/>', N'', N'', 1, 338)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.4.5 Description', N'<w:alias w:val="5.5.4.5 Description"/>', N'', N'', 1, 339)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.5 What is the estimated annual operating', N'<w:alias w:val="5.5.5 What is the estimated annual operating"/>', N'', N'', 1, 340)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.6 If applicable, are there any other future maintenance ', N'<w:alias w:val="5.5.6 If applicable, are there any other future maintenance "/>', N'', N'', 1, 341)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.1 Deliverable', N'<w:alias w:val="5.5.7.1.1 Deliverable"/>', N'', N'', 1, 342)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.1 Level of Effort', N'<w:alias w:val="5.5.7.1.1 Level of Effort"/>', N'', N'', 1, 343)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.1 Position', N'<w:alias w:val="5.5.7.1.1 Position"/>', N'', N'', 1, 344)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.1 Skill Description', N'<w:alias w:val="5.5.7.1.1 Skill Description"/>', N'', N'', 1, 345)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.2 Deliverable', N'<w:alias w:val="5.5.7.1.2 Deliverable"/>', N'', N'', 1, 346)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.2 Level of Effort', N'<w:alias w:val="5.5.7.1.2 Level of Effort"/>', N'', N'', 1, 347)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.2 Position', N'<w:alias w:val="5.5.7.1.2 Position"/>', N'', N'', 1, 348)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.2 Skill Description', N'<w:alias w:val="5.5.7.1.2 Skill Description"/>', N'', N'', 1, 349)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.3 Deliverable', N'<w:alias w:val="5.5.7.1.3 Deliverable"/>', N'', N'', 1, 350)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.3 Level of Effort', N'<w:alias w:val="5.5.7.1.3 Level of Effort"/>', N'', N'', 1, 351)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.3 Position', N'<w:alias w:val="5.5.7.1.3 Position"/>', N'', N'', 1, 352)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.3 Skill Description', N'<w:alias w:val="5.5.7.1.3 Skill Description"/>', N'', N'', 1, 353)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.4 Deliverable', N'<w:alias w:val="5.5.7.1.4 Deliverable"/>', N'', N'', 1, 354)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.4 Level of Effort', N'<w:alias w:val="5.5.7.1.4 Level of Effort"/>', N'', N'', 1, 355)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.4 Position', N'<w:alias w:val="5.5.7.1.4 Position"/>', N'', N'', 1, 356)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.4 Skill Description', N'<w:alias w:val="5.5.7.1.4 Skill Description"/>', N'', N'', 1, 357)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.5 Deliverable', N'<w:alias w:val="5.5.7.1.5 Deliverable"/>', N'', N'', 1, 358)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.5 Level of Effort', N'<w:alias w:val="5.5.7.1.5 Level of Effort"/>', N'', N'', 1, 359)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.5 Position', N'<w:alias w:val="5.5.7.1.5 Position"/>', N'', N'', 1, 360)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.1.5 Skill Description', N'<w:alias w:val="5.5.7.1.5 Skill Description"/>', N'', N'', 1, 361)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.1 Deliverable', N'<w:alias w:val="5.5.7.2.1 Deliverable"/>', N'', N'', 1, 362)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.1 Level of Effort', N'<w:alias w:val="5.5.7.2.1 Level of Effort"/>', N'', N'', 1, 363)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.1 Position', N'<w:alias w:val="5.5.7.2.1 Position"/>', N'', N'', 1, 364)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.1 Skill Description', N'<w:alias w:val="5.5.7.2.1 Skill Description"/>', N'', N'', 1, 365)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.2 Deliverable', N'<w:alias w:val="5.5.7.2.2 Deliverable"/>', N'', N'', 1, 366)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.2 Level of Effort', N'<w:alias w:val="5.5.7.2.2 Level of Effort"/>', N'', N'', 1, 367)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.2 Position', N'<w:alias w:val="5.5.7.2.2 Position"/>', N'', N'', 1, 368)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.2 Skill Description', N'<w:alias w:val="5.5.7.2.2 Skill Description"/>', N'', N'', 1, 369)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.3 Deliverable', N'<w:alias w:val="5.5.7.2.3 Deliverable"/>', N'', N'', 1, 370)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.3 Level of Effort', N'<w:alias w:val="5.5.7.2.3 Level of Effort"/>', N'', N'', 1, 371)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.3 Position', N'<w:alias w:val="5.5.7.2.3 Position"/>', N'', N'', 1, 372)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.3 Skill Description', N'<w:alias w:val="5.5.7.2.3 Skill Description"/>', N'', N'', 1, 373)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.4 Deliverable', N'<w:alias w:val="5.5.7.2.4 Deliverable"/>', N'', N'', 1, 374)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.4 Level of Effort', N'<w:alias w:val="5.5.7.2.4 Level of Effort"/>', N'', N'', 1, 375)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.4 Position', N'<w:alias w:val="5.5.7.2.4 Position"/>', N'', N'', 1, 376)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.4 Skill Description', N'<w:alias w:val="5.5.7.2.4 Skill Description"/>', N'', N'', 1, 377)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.5 Deliverable', N'<w:alias w:val="5.5.7.2.5 Deliverable"/>', N'', N'', 1, 378)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.5 Level of Effort', N'<w:alias w:val="5.5.7.2.5 Level of Effort"/>', N'', N'', 1, 379)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.5 Position', N'<w:alias w:val="5.5.7.2.5 Position"/>', N'', N'', 1, 380)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.2.5 Skill Description', N'<w:alias w:val="5.5.7.2.5 Skill Description"/>', N'', N'', 1, 381)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.1 Deliverable', N'<w:alias w:val="5.5.7.3.1 Deliverable"/>', N'', N'', 1, 382)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.1 Duration', N'<w:alias w:val="5.5.7.3.1 Duration"/>', N'', N'', 1, 383)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.1 Resource', N'<w:alias w:val="5.5.7.3.1 Resource"/>', N'', N'', 1, 384)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.1 Resource Description', N'<w:alias w:val="5.5.7.3.1 Resource Description"/>', N'', N'', 1, 385)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.2 Deliverable', N'<w:alias w:val="5.5.7.3.2 Deliverable"/>', N'', N'', 1, 386)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.2 Duration', N'<w:alias w:val="5.5.7.3.2 Duration"/>', N'', N'', 1, 387)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.2 Resource', N'<w:alias w:val="5.5.7.3.2 Resource"/>', N'', N'', 1, 388)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.2 Resource Description', N'<w:alias w:val="5.5.7.3.2 Resource Description"/>', N'', N'', 1, 389)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.3 Deliverable', N'<w:alias w:val="5.5.7.3.3 Deliverable"/>', N'', N'', 1, 390)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.3 Duration', N'<w:alias w:val="5.5.7.3.3 Duration"/>', N'', N'', 1, 391)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.3 Resource', N'<w:alias w:val="5.5.7.3.3 Resource"/>', N'', N'', 1, 392)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.3 Resource Description', N'<w:alias w:val="5.5.7.3.3 Resource Description"/>', N'', N'', 1, 393)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.4 Deliverable', N'<w:alias w:val="5.5.7.3.4 Deliverable"/>', N'', N'', 1, 394)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.4 Duration', N'<w:alias w:val="5.5.7.3.4 Duration"/>', N'', N'', 1, 395)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.4 Resource', N'<w:alias w:val="5.5.7.3.4 Resource"/>', N'', N'', 1, 396)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.4 Resource Description', N'<w:alias w:val="5.5.7.3.4 Resource Description"/>', N'', N'', 1, 397)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.5 Deliverable', N'<w:alias w:val="5.5.7.3.5 Deliverable"/>', N'', N'', 1, 398)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.5 Duration', N'<w:alias w:val="5.5.7.3.5 Duration"/>', N'', N'', 1, 399)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.5 Resource', N'<w:alias w:val="5.5.7.3.5 Resource"/>', N'', N'', 1, 400)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.3.5 Resource Description', N'<w:alias w:val="5.5.7.3.5 Resource Description"/>', N'', N'', 1, 401)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.1 Deliverable', N'<w:alias w:val="5.5.7.4.1 Deliverable"/>', N'', N'', 1, 402)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.1 Duration', N'<w:alias w:val="5.5.7.4.1 Duration"/>', N'', N'', 1, 403)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.1 Resource', N'<w:alias w:val="5.5.7.4.1 Resource"/>', N'', N'', 1, 404)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.1 Resource Description', N'<w:alias w:val="5.5.7.4.1 Resource Description"/>', N'', N'', 1, 405)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.2 Deliverable', N'<w:alias w:val="5.5.7.4.2 Deliverable"/>', N'', N'', 1, 406)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.2 Duration', N'<w:alias w:val="5.5.7.4.2 Duration"/>', N'', N'', 1, 407)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.2 Resource', N'<w:alias w:val="5.5.7.4.2 Resource"/>', N'', N'', 1, 408)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.2 Resource Description', N'<w:alias w:val="5.5.7.4.2 Resource Description"/>', N'', N'', 1, 409)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.3 Deliverable', N'<w:alias w:val="5.5.7.4.3 Deliverable"/>', N'', N'', 1, 410)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.3 Duration', N'<w:alias w:val="5.5.7.4.3 Duration"/>', N'', N'', 1, 411)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.3 Resource', N'<w:alias w:val="5.5.7.4.3 Resource"/>', N'', N'', 1, 412)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.3 Resource Description', N'<w:alias w:val="5.5.7.4.3 Resource Description"/>', N'', N'', 1, 413)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.4 Deliverable', N'<w:alias w:val="5.5.7.4.4 Deliverable"/>', N'', N'', 1, 414)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.4 Duration', N'<w:alias w:val="5.5.7.4.4 Duration"/>', N'', N'', 1, 415)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.4 Resource', N'<w:alias w:val="5.5.7.4.4 Resource"/>', N'', N'', 1, 416)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.4 Resource Description', N'<w:alias w:val="5.5.7.4.4 Resource Description"/>', N'', N'', 1, 417)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.5 Deliverable', N'<w:alias w:val="5.5.7.4.5 Deliverable"/>', N'', N'', 1, 418)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.5 Duration', N'<w:alias w:val="5.5.7.4.5 Duration"/>', N'', N'', 1, 419)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.5 Resource', N'<w:alias w:val="5.5.7.4.5 Resource"/>', N'', N'', 1, 420)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.7.4.5 Resource Description', N'<w:alias w:val="5.5.7.4.5 Resource Description"/>', N'', N'', 1, 421)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.5.8 Overall, why is this business case the most appropriate', N'<w:alias w:val="5.5.8 Overall, why is this business case the most appropriate"/>', N'', N'', 1, 422)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.1 Potential achievability', N'<w:alias w:val="5.6.1.1 Potential achievability"/>', N'', N'', 1, 423)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.1 Potential affordability', N'<w:alias w:val="5.6.1.1 Potential affordability"/>', N'', N'', 1, 424)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.1 Strategic fit and business needs', N'<w:alias w:val="5.6.1.1 Strategic fit and business needs"/>', N'', N'', 1, 425)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.1 Summary', N'<w:alias w:val="5.6.1.1 Summary"/>', N'', N'', 1, 426)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.2 Potential achievability', N'<w:alias w:val="5.6.1.2 Potential achievability"/>', N'', N'', 1, 427)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.2 Potential affordability', N'<w:alias w:val="5.6.1.2 Potential affordability"/>', N'', N'', 1, 428)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.2 Strategic fit and business needs', N'<w:alias w:val="5.6.1.2 Strategic fit and business needs"/>', N'', N'', 1, 429)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.2 Summary', N'<w:alias w:val="5.6.1.2 Summary"/>', N'', N'', 1, 430)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.3 Potential achievability', N'<w:alias w:val="5.6.1.3 Potential achievability"/>', N'', N'', 1, 431)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.3 Potential affordability', N'<w:alias w:val="5.6.1.3 Potential affordability"/>', N'', N'', 1, 432)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.3 Strategic fit and business needs', N'<w:alias w:val="5.6.1.3 Strategic fit and business needs"/>', N'', N'', 1, 433)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.3 Summary', N'<w:alias w:val="5.6.1.3 Summary"/>', N'', N'', 1, 434)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.4 Potential achievability', N'<w:alias w:val="5.6.1.4 Potential achievability"/>', N'', N'', 1, 435)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.4 Potential affordability', N'<w:alias w:val="5.6.1.4 Potential affordability"/>', N'', N'', 1, 436)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.4 Strategic fit and business needs', N'<w:alias w:val="5.6.1.4 Strategic fit and business needs"/>', N'', N'', 1, 437)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.4 Summary', N'<w:alias w:val="5.6.1.4 Summary"/>', N'', N'', 1, 438)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.5 Potential achievability', N'<w:alias w:val="5.6.1.5 Potential achievability"/>', N'', N'', 1, 439)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.5 Potential affordability', N'<w:alias w:val="5.6.1.5 Potential affordability"/>', N'', N'', 1, 440)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.5 Strategic fit and business needs', N'<w:alias w:val="5.6.1.5 Strategic fit and business needs"/>', N'', N'', 1, 441)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.6.1.5 Summary', N'<w:alias w:val="5.6.1.5 Summary"/>', N'', N'', 1, 442)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.7.1 Summary of Viable Option 1', N'<w:alias w:val="5.7.1 Summary of Viable Option 1"/>', N'', N'', 1, 443)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.7.2 Summary of Viable Option 2', N'<w:alias w:val="5.7.2 Summary of Viable Option 2"/>', N'', N'', 1, 444)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.7.3 Final Recommendation', N'<w:alias w:val="5.7.3 Final Recommendation"/>', N'', N'', 1, 445)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'5.7.4 Rationale', N'<w:alias w:val="5.7.4 Rationale"/>', N'', N'', 1, 446)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.1 Project Management Strategy', N'<w:alias w:val="6.1.1 Project Management Strategy"/>', N'', N'', 1, 447)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.1 Key Activities', N'<w:alias w:val="6.1.2.1 Key Activities"/>', N'', N'', 1, 448)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.1 Milestone', N'<w:alias w:val="6.1.2.1 Milestone"/>', N'', N'', 1, 449)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.1 Target Date', N'<w:alias w:val="6.1.2.1 Target Date"/>', N'', N'', 1, 450)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.1 Work Product(s)', N'<w:alias w:val="6.1.2.1 Work Product(s)"/>', N'', N'', 1, 451)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.1 Work Stream', N'<w:alias w:val="6.1.2.1 Work Stream"/>', N'', N'', 1, 452)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.10 Key Activities', N'<w:alias w:val="6.1.2.10 Key Activities"/>', N'', N'', 1, 453)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.10 Milestone', N'<w:alias w:val="6.1.2.10 Milestone"/>', N'', N'', 1, 454)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.10 Target Date', N'<w:alias w:val="6.1.2.10 Target Date"/>', N'', N'', 1, 455)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.10 Work Product(s)', N'<w:alias w:val="6.1.2.10 Work Product(s)"/>', N'', N'', 1, 456)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.10 Work Stream', N'<w:alias w:val="6.1.2.10 Work Stream"/>', N'', N'', 1, 457)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.2 Key Activities', N'<w:alias w:val="6.1.2.2 Key Activities"/>', N'', N'', 1, 458)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.2 Milestone', N'<w:alias w:val="6.1.2.2 Milestone"/>', N'', N'', 1, 459)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.2 Target Date', N'<w:alias w:val="6.1.2.2 Target Date"/>', N'', N'', 1, 460)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.2 Work Product(s)', N'<w:alias w:val="6.1.2.2 Work Product(s)"/>', N'', N'', 1, 461)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.2 Work Stream', N'<w:alias w:val="6.1.2.2 Work Stream"/>', N'', N'', 1, 462)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.3 Key Activities', N'<w:alias w:val="6.1.2.3 Key Activities"/>', N'', N'', 1, 463)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.3 Milestone', N'<w:alias w:val="6.1.2.3 Milestone"/>', N'', N'', 1, 464)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.3 Target Date', N'<w:alias w:val="6.1.2.3 Target Date"/>', N'', N'', 1, 465)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.3 Work Product(s)', N'<w:alias w:val="6.1.2.3 Work Product(s)"/>', N'', N'', 1, 466)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.3 Work Stream', N'<w:alias w:val="6.1.2.3 Work Stream"/>', N'', N'', 1, 467)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.4 Key Activities', N'<w:alias w:val="6.1.2.4 Key Activities"/>', N'', N'', 1, 468)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.4 Milestone', N'<w:alias w:val="6.1.2.4 Milestone"/>', N'', N'', 1, 469)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.4 Target Date', N'<w:alias w:val="6.1.2.4 Target Date"/>', N'', N'', 1, 470)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.4 Work Product(s)', N'<w:alias w:val="6.1.2.4 Work Product(s)"/>', N'', N'', 1, 471)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.4 Work Stream', N'<w:alias w:val="6.1.2.4 Work Stream"/>', N'', N'', 1, 472)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.5 Key Activities', N'<w:alias w:val="6.1.2.5 Key Activities"/>', N'', N'', 1, 473)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.5 Milestone', N'<w:alias w:val="6.1.2.5 Milestone"/>', N'', N'', 1, 474)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.5 Target Date', N'<w:alias w:val="6.1.2.5 Target Date"/>', N'', N'', 1, 475)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.5 Work Product(s)', N'<w:alias w:val="6.1.2.5 Work Product(s)"/>', N'', N'', 1, 476)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.5 Work Stream', N'<w:alias w:val="6.1.2.5 Work Stream"/>', N'', N'', 1, 477)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.6 Key Activities', N'<w:alias w:val="6.1.2.6 Key Activities"/>', N'', N'', 1, 478)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.6 Milestone', N'<w:alias w:val="6.1.2.6 Milestone"/>', N'', N'', 1, 479)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.6 Target Date', N'<w:alias w:val="6.1.2.6 Target Date"/>', N'', N'', 1, 480)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.6 Work Product(s)', N'<w:alias w:val="6.1.2.6 Work Product(s)"/>', N'', N'', 1, 481)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.6 Work Stream', N'<w:alias w:val="6.1.2.6 Work Stream"/>', N'', N'', 1, 482)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.7 Key Activities', N'<w:alias w:val="6.1.2.7 Key Activities"/>', N'', N'', 1, 483)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.7 Milestone', N'<w:alias w:val="6.1.2.7 Milestone"/>', N'', N'', 1, 484)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.7 Target Date', N'<w:alias w:val="6.1.2.7 Target Date"/>', N'', N'', 1, 485)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.7 Work Product(s)', N'<w:alias w:val="6.1.2.7 Work Product(s)"/>', N'', N'', 1, 486)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.7 Work Stream', N'<w:alias w:val="6.1.2.7 Work Stream"/>', N'', N'', 1, 487)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.8 Key Activities', N'<w:alias w:val="6.1.2.8 Key Activities"/>', N'', N'', 1, 488)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.8 Milestone', N'<w:alias w:val="6.1.2.8 Milestone"/>', N'', N'', 1, 489)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.8 Target Date', N'<w:alias w:val="6.1.2.8 Target Date"/>', N'', N'', 1, 490)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.8 Work Product(s)', N'<w:alias w:val="6.1.2.8 Work Product(s)"/>', N'', N'', 1, 491)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.8 Work Stream', N'<w:alias w:val="6.1.2.8 Work Stream"/>', N'', N'', 1, 492)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.9 Key Activities', N'<w:alias w:val="6.1.2.9 Key Activities"/>', N'', N'', 1, 493)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.9 Milestone', N'<w:alias w:val="6.1.2.9 Milestone"/>', N'', N'', 1, 494)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.9 Target Date', N'<w:alias w:val="6.1.2.9 Target Date"/>', N'', N'', 1, 495)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.9 Work Product(s)', N'<w:alias w:val="6.1.2.9 Work Product(s)"/>', N'', N'', 1, 496)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.2.9 Work Stream', N'<w:alias w:val="6.1.2.9 Work Stream"/>', N'', N'', 1, 497)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.1 Business Need', N'<w:alias w:val="6.1.3.1 Business Need"/>', N'', N'', 1, 498)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.1 Level of Effort', N'<w:alias w:val="6.1.3.1 Level of Effort"/>', N'', N'', 1, 499)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.1 Planned % Work Complete', N'<w:alias w:val="6.1.3.1 Planned % Work Complete"/>', N'', N'', 1, 500)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.1 Planned Costs', N'<w:alias w:val="6.1.3.1 Planned Costs"/>', N'', N'', 1, 501)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.1 Planned Schedule', N'<w:alias w:val="6.1.3.1 Planned Schedule"/>', N'', N'', 1, 502)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.1 Resource Type', N'<w:alias w:val="6.1.3.1 Resource Type"/>', N'', N'', 1, 503)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.1 Work Product', N'<w:alias w:val="6.1.3.1 Work Product"/>', N'', N'', 1, 504)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.2 Business Need', N'<w:alias w:val="6.1.3.2 Business Need"/>', N'', N'', 1, 505)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.2 Level of Effort', N'<w:alias w:val="6.1.3.2 Level of Effort"/>', N'', N'', 1, 506)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.2 Planned % Work Complete', N'<w:alias w:val="6.1.3.2 Planned % Work Complete"/>', N'', N'', 1, 507)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.2 Planned Costs', N'<w:alias w:val="6.1.3.2 Planned Costs"/>', N'', N'', 1, 508)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.2 Planned Schedule', N'<w:alias w:val="6.1.3.2 Planned Schedule"/>', N'', N'', 1, 509)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.2 Resource Type', N'<w:alias w:val="6.1.3.2 Resource Type"/>', N'', N'', 1, 510)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.2 Work Product', N'<w:alias w:val="6.1.3.2 Work Product"/>', N'', N'', 1, 511)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.3 Business Need', N'<w:alias w:val="6.1.3.3 Business Need"/>', N'', N'', 1, 512)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.3 Level of Effort', N'<w:alias w:val="6.1.3.3 Level of Effort"/>', N'', N'', 1, 513)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.3 Planned % Work Complete', N'<w:alias w:val="6.1.3.3 Planned % Work Complete"/>', N'', N'', 1, 514)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.3 Planned Costs', N'<w:alias w:val="6.1.3.3 Planned Costs"/>', N'', N'', 1, 515)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.3 Planned Schedule', N'<w:alias w:val="6.1.3.3 Planned Schedule"/>', N'', N'', 1, 516)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.3 Resource Type', N'<w:alias w:val="6.1.3.3 Resource Type"/>', N'', N'', 1, 517)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.3 Work Product', N'<w:alias w:val="6.1.3.3 Work Product"/>', N'', N'', 1, 518)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.4 Business Need', N'<w:alias w:val="6.1.3.4 Business Need"/>', N'', N'', 1, 519)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.4 Level of Effort', N'<w:alias w:val="6.1.3.4 Level of Effort"/>', N'', N'', 1, 520)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.4 Planned % Work Complete', N'<w:alias w:val="6.1.3.4 Planned % Work Complete"/>', N'', N'', 1, 521)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.4 Planned Costs', N'<w:alias w:val="6.1.3.4 Planned Costs"/>', N'', N'', 1, 522)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.4 Planned Schedule', N'<w:alias w:val="6.1.3.4 Planned Schedule"/>', N'', N'', 1, 523)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.4 Resource Type', N'<w:alias w:val="6.1.3.4 Resource Type"/>', N'', N'', 1, 524)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.4 Work Product', N'<w:alias w:val="6.1.3.4 Work Product"/>', N'', N'', 1, 525)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.5 Business Need', N'<w:alias w:val="6.1.3.5 Business Need"/>', N'', N'', 1, 526)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.5 Level of Effort', N'<w:alias w:val="6.1.3.5 Level of Effort"/>', N'', N'', 1, 527)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.5 Planned % Work Complete', N'<w:alias w:val="6.1.3.5 Planned % Work Complete"/>', N'', N'', 1, 528)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.5 Planned Costs', N'<w:alias w:val="6.1.3.5 Planned Costs"/>', N'', N'', 1, 529)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.5 Planned Schedule', N'<w:alias w:val="6.1.3.5 Planned Schedule"/>', N'', N'', 1, 530)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.5 Resource Type', N'<w:alias w:val="6.1.3.5 Resource Type"/>', N'', N'', 1, 531)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.3.5 Work Product', N'<w:alias w:val="6.1.3.5 Work Product"/>', N'', N'', 1, 532)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.4.1 Element', N'<w:alias w:val="6.1.4.1 Element"/>', N'', N'', 1, 533)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.4.1 Is dependent upon [action] from [entity]', N'<w:alias w:val="6.1.4.1 Is dependent upon [action] from [entity]"/>', N'', N'', 1, 534)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.4.2 Element', N'<w:alias w:val="6.1.4.2 Element"/>', N'', N'', 1, 535)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.4.2 Is dependent upon [action] from [entity]', N'<w:alias w:val="6.1.4.2 Is dependent upon [action] from [entity]"/>', N'', N'', 1, 536)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.4.3 Element', N'<w:alias w:val="6.1.4.3 Element"/>', N'', N'', 1, 537)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.4.3 Is dependent upon [action] from [entity]', N'<w:alias w:val="6.1.4.3 Is dependent upon [action] from [entity]"/>', N'', N'', 1, 538)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.4.4 Element', N'<w:alias w:val="6.1.4.4 Element"/>', N'', N'', 1, 539)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.4.4 Is dependent upon [action] from [entity]', N'<w:alias w:val="6.1.4.4 Is dependent upon [action] from [entity]"/>', N'', N'', 1, 540)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.4.5 Element', N'<w:alias w:val="6.1.4.5 Element"/>', N'', N'', 1, 541)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.4.5 Is dependent upon [action] from [entity]', N'<w:alias w:val="6.1.4.5 Is dependent upon [action] from [entity]"/>', N'', N'', 1, 542)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.1.5 Provide an overview of the methods and processes', N'<w:alias w:val="6.1.5 Provide an overview of the methods and processes"/>', N'', N'', 1, 543)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.1 Impact', N'<w:alias w:val="6.2.1.1 Impact"/>', N'', N'', 1, 544)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.1 Planned Mitigation', N'<w:alias w:val="6.2.1.1 Planned Mitigation"/>', N'', N'', 1, 545)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.1 Probability', N'<w:alias w:val="6.2.1.1 Probability"/>', N'', N'', 1, 546)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.1 Risk Indicator', N'<w:alias w:val="6.2.1.1 Risk Indicator"/>', N'', N'', 1, 547)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.1 Risk Statement', N'<w:alias w:val="6.2.1.1 Risk Statement"/>', N'', N'', 1, 548)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.2 Impact', N'<w:alias w:val="6.2.1.2 Impact"/>', N'', N'', 1, 549)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.2 Planned Mitigation', N'<w:alias w:val="6.2.1.2 Planned Mitigation"/>', N'', N'', 1, 550)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.2 Probability', N'<w:alias w:val="6.2.1.2 Probability"/>', N'', N'', 1, 551)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.2 Risk Indicator', N'<w:alias w:val="6.2.1.2 Risk Indicator"/>', N'', N'', 1, 552)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.2 Risk Statement', N'<w:alias w:val="6.2.1.2 Risk Statement"/>', N'', N'', 1, 553)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.3 Impact', N'<w:alias w:val="6.2.1.3 Impact"/>', N'', N'', 1, 554)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.3 Planned Mitigation', N'<w:alias w:val="6.2.1.3 Planned Mitigation"/>', N'', N'', 1, 555)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.3 Probability', N'<w:alias w:val="6.2.1.3 Probability"/>', N'', N'', 1, 556)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.3 Risk Indicator', N'<w:alias w:val="6.2.1.3 Risk Indicator"/>', N'', N'', 1, 557)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.3 Risk Statement', N'<w:alias w:val="6.2.1.3 Risk Statement"/>', N'', N'', 1, 558)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.4 Impact', N'<w:alias w:val="6.2.1.4 Impact"/>', N'', N'', 1, 559)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.4 Planned Mitigation', N'<w:alias w:val="6.2.1.4 Planned Mitigation"/>', N'', N'', 1, 560)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.4 Probability', N'<w:alias w:val="6.2.1.4 Probability"/>', N'', N'', 1, 561)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.4 Risk Indicator', N'<w:alias w:val="6.2.1.4 Risk Indicator"/>', N'', N'', 1, 562)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.4 Risk Statement', N'<w:alias w:val="6.2.1.4 Risk Statement"/>', N'', N'', 1, 563)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.5 Impact', N'<w:alias w:val="6.2.1.5 Impact"/>', N'', N'', 1, 564)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.5 Planned Mitigation', N'<w:alias w:val="6.2.1.5 Planned Mitigation"/>', N'', N'', 1, 565)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.5 Probability', N'<w:alias w:val="6.2.1.5 Probability"/>', N'', N'', 1, 566)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.5 Risk Indicator', N'<w:alias w:val="6.2.1.5 Risk Indicator"/>', N'', N'', 1, 567)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.2.1.5 Risk Statement', N'<w:alias w:val="6.2.1.5 Risk Statement"/>', N'', N'', 1, 568)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.3.1 Describe the potential impact of the proposed change', N'<w:alias w:val="6.3.1 Describe the potential impact of the proposed change"/>', N'', N'', 1, 569)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.1 Business Case Goals', N'<w:alias w:val="6.4.1.1 Business Case Goals"/>', N'', N'', 1, 570)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.1 Objectives', N'<w:alias w:val="6.4.1.1 Objectives"/>', N'', N'', 1, 571)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.1 Performance Measures', N'<w:alias w:val="6.4.1.1 Performance Measures"/>', N'', N'', 1, 572)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.1 Targets (for benefits realization)', N'<w:alias w:val="6.4.1.1 Targets (for benefits realization)"/>', N'', N'', 1, 573)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.2 Business Case Goals', N'<w:alias w:val="6.4.1.2 Business Case Goals"/>', N'', N'', 1, 574)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.2 Objectives', N'<w:alias w:val="6.4.1.2 Objectives"/>', N'', N'', 1, 575)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.2 Performance Measures', N'<w:alias w:val="6.4.1.2 Performance Measures"/>', N'', N'', 1, 576)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.2 Targets (for benefits realization)', N'<w:alias w:val="6.4.1.2 Targets (for benefits realization)"/>', N'', N'', 1, 577)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.3 Business Case Goals', N'<w:alias w:val="6.4.1.3 Business Case Goals"/>', N'', N'', 1, 578)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.3 Objectives', N'<w:alias w:val="6.4.1.3 Objectives"/>', N'', N'', 1, 579)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.3 Performance Measures', N'<w:alias w:val="6.4.1.3 Performance Measures"/>', N'', N'', 1, 580)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.3 Targets (for benefits realization)', N'<w:alias w:val="6.4.1.3 Targets (for benefits realization)"/>', N'', N'', 1, 581)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.4 Business Case Goals', N'<w:alias w:val="6.4.1.4 Business Case Goals"/>', N'', N'', 1, 582)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.4 Objectives', N'<w:alias w:val="6.4.1.4 Objectives"/>', N'', N'', 1, 583)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.4 Performance Measures', N'<w:alias w:val="6.4.1.4 Performance Measures"/>', N'', N'', 1, 584)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.4 Targets (for benefits realization)', N'<w:alias w:val="6.4.1.4 Targets (for benefits realization)"/>', N'', N'', 1, 585)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.5 Business Case Goals', N'<w:alias w:val="6.4.1.5 Business Case Goals"/>', N'', N'', 1, 586)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.5 Objectives', N'<w:alias w:val="6.4.1.5 Objectives"/>', N'', N'', 1, 587)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.5 Performance Measures', N'<w:alias w:val="6.4.1.5 Performance Measures"/>', N'', N'', 1, 588)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'6.4.1.5 Targets (for benefits realization)', N'<w:alias w:val="6.4.1.5 Targets (for benefits realization)"/>', N'', N'', 1, 589)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.1.1 Effects on investment', N'<w:alias w:val="7.1.1 Effects on investment"/>', N'', N'', 1, 590)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.1.1 It is assumed that', N'<w:alias w:val="7.1.1 It is assumed that"/>', N'', N'', 1, 591)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.1.1 Reliability Level', N'<w:alias w:val="7.1.1 Reliability Level"/>', N'', N'', 1, 592)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.1.2 Effects on investment', N'<w:alias w:val="7.1.2 Effects on investment"/>', N'', N'', 1, 593)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.1.2 It is assumed that', N'<w:alias w:val="7.1.2 It is assumed that"/>', N'', N'', 1, 594)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.1.2 Reliability Level', N'<w:alias w:val="7.1.2 Reliability Level"/>', N'', N'', 1, 595)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.1.3 Effects on investment', N'<w:alias w:val="7.1.3 Effects on investment"/>', N'', N'', 1, 596)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.1.3 It is assumed that', N'<w:alias w:val="7.1.3 It is assumed that"/>', N'', N'', 1, 597)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.1.3 Reliability Level', N'<w:alias w:val="7.1.3 Reliability Level"/>', N'', N'', 1, 598)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.1.4 Effects on investment', N'<w:alias w:val="7.1.4 Effects on investment"/>', N'', N'', 1, 599)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.1.4 It is assumed that', N'<w:alias w:val="7.1.4 It is assumed that"/>', N'', N'', 1, 600)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.1.4 Reliability Level', N'<w:alias w:val="7.1.4 Reliability Level"/>', N'', N'', 1, 601)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.1.5 Effects on investment', N'<w:alias w:val="7.1.5 Effects on investment"/>', N'', N'', 1, 602)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.1.5 It is assumed that', N'<w:alias w:val="7.1.5 It is assumed that"/>', N'', N'', 1, 603)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.1.5 Reliability Level', N'<w:alias w:val="7.1.5 Reliability Level"/>', N'', N'', 1, 604)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.2 Constraints - List and describe', N'<w:alias w:val="7.2 Constraints - List and describe"/>', N'', N'', 1, 605)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'7.3 Are there any other relevant factors or considerations', N'<w:alias w:val="7.3 Are there any other relevant factors or considerations"/>', N'', N'', 1, 606)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'8.1 Acronym', N'<w:alias w:val="8.1 Acronym"/>', N'', N'', 1, 607)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'8.1 In Full', N'<w:alias w:val="8.1 In Full"/>', N'', N'', 1, 608)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'8.2 Acronym', N'<w:alias w:val="8.2 Acronym"/>', N'', N'', 1, 609)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'8.2 In Full', N'<w:alias w:val="8.2 In Full"/>', N'', N'', 1, 610)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'8.3 Acronym', N'<w:alias w:val="8.3 Acronym"/>', N'', N'', 1, 611)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'8.3 In Full', N'<w:alias w:val="8.3 In Full"/>', N'', N'', 1, 612)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'8.4 Acronym', N'<w:alias w:val="8.4 Acronym"/>', N'', N'', 1, 613)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'8.4 In Full', N'<w:alias w:val="8.4 In Full"/>', N'', N'', 1, 614)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'8.5 Acronym', N'<w:alias w:val="8.5 Acronym"/>', N'', N'', 1, 615)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'8.5 In Full', N'<w:alias w:val="8.5 In Full"/>', N'', N'', 1, 616)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'9.1 Definition', N'<w:alias w:val="9.1 Definition"/>', N'', N'', 1, 617)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'9.1 Term', N'<w:alias w:val="9.1 Term"/>', N'', N'', 1, 618)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'9.2 Definition', N'<w:alias w:val="9.2 Definition"/>', N'', N'', 1, 619)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'9.2 Term', N'<w:alias w:val="9.2 Term"/>', N'', N'', 1, 620)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'9.3 Definition', N'<w:alias w:val="9.3 Definition"/>', N'', N'', 1, 621)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'9.3 Term', N'<w:alias w:val="9.3 Term"/>', N'', N'', 1, 622)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'9.4 Definition', N'<w:alias w:val="9.4 Definition"/>', N'', N'', 1, 623)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'9.4 Term', N'<w:alias w:val="9.4 Term"/>', N'', N'', 1, 624)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'9.5 Definition', N'<w:alias w:val="9.5 Definition"/>', N'', N'', 1, 625)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'9.5 Term', N'<w:alias w:val="9.5 Term"/>', N'', N'', 1, 626)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'9.6 Definition', N'<w:alias w:val="9.6 Definition"/>', N'', N'', 1, 627)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'9.6 Term', N'<w:alias w:val="9.6 Term"/>', N'', N'', 1, 628)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'9.7 Definition', N'<w:alias w:val="9.7 Definition"/>', N'', N'', 1, 629)
GO
INSERT [dbo].[Form] ([Form], [StartString], [EndString], [FilterPatent], [Active], [NBR]) VALUES (N'9.7 Term', N'<w:alias w:val="9.7 Term"/>', N'', N'', 1, 630)
GO
SET IDENTITY_INSERT [dbo].[Tag] ON 
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (1, N'<w:t>')
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (2, N'</w:t></w:r></w:p></w:tc></w:sdtContent></w:sdt></w:tr>')
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (3, N'<w:date w:fullDate="')
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (4, N'>')
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (5, N'</w:t></w:r></w:p></w:tc>')
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (6, N'</w:t></w:r></w:sdtContent></w:sdt></w:p></w:tc></w:tr>')
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (7, N'</w:t></w:r>')
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (8, N'</w:t></w:r></w:p></w:tc>')
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (9, N'</w:t></w:r></w:p>')
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (10, N'</w:t></w:r></w:p></w:tc></w:sdtContent></w:sdt></w:tr></w:tbl>')
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (11, N'</w:sdtContent</w:sdt')
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (12, N'<w14:checkedState w14:val="2612" w14:font="MS Gothic"/><w14:uncheckedState w14:val="2610" w14:font="MS Gothic"/></w14:checkbox></w:sdtPr>')
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (13, N'</w:t></w:r></w:p></w:sdtContent></w:sdt>')
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (14, N'</w:sdtContent</w:sdt</w:p</w:sdtContent</w:sdt')
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (15, N'</w:sdtContent')
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (16, N'</w:sdt')
GO
INSERT [dbo].[Tag] ([ID], [Value]) VALUES (17, N'</w:p')
GO
SET IDENTITY_INSERT [dbo].[Tag] OFF
GO
