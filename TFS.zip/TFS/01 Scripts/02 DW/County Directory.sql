/* DEVLOPER CONTACT 
Ken Liu
Data Systems Analyst, Enterprise Information Management - Information Technology Services (ITS)
Strathcona County | 2001 Sherwood Drive | Sherwood Park, AB |T8A 3W7
Office: 780-410-8563  Cell: 780-405-1938
eMail:  ken.liu@strathcona.ca 
*/

DECLARE @DPET TABLE( CODE INT,ParentCode INT,DEPT_NAME VARCHAR(250),PARENT_DEPT_NAME VARCHAR(250) ,OrganizationTypeCode_Name VARCHAR(250),
Phone VARCHAR(250),Cellular VARCHAR(250),Fax VARCHAR(250),LocationID_Name VARCHAR(250),ShortName VARCHAR(100))

DECLARE @ORG TABLE (
	[DIV] [varchar](250) NULL,
	[DEPT] [varchar](250) NULL,
	DEPT_SHORT_NAME [varchar](250) NULL,
	[DEPT_ADDRESS] [varchar](250) NULL,
	[DEPT_PHONE] [varchar](250) NULL,
	[DEPT_CELLULAR] [varchar](250) NULL,
	[DEPT_FAX] [varchar](250) NULL,
	[DEPT_LATITUDE] [nvarchar](100) NULL,
	[DEPT_LONGITUDE] [nvarchar](100) NULL,
	[ORG_NAME] [varchar](250) NULL,
	ORG_SHORT_NAME [varchar](250) NULL,
	[CODE] [int] NULL,
	[ORG_ADDRESS] [varchar](250) NULL,
	[ORG_PHONE] [varchar](250) NULL,
	[ORG_CELLULAR] [varchar](250) NULL,
	[ORG_FAX] [varchar](250) NULL,
	[ORG_LATITUDE] [nvarchar](100) NULL,
	[ORG_LONGITUDE] [nvarchar](100) NULL,
	[PARENT_CODE] [int] NULL,
	[PATH_NAME] [varchar](8000) NULL,
	[TREE_LEVEL] [int] NULL,
	[TREE_PATH] [varchar](250) NULL,
	[ORGANIZATION_TYPE] [varchar](250) NULL,
	[DISPLAY_ORDER] [int] NOT NULL
)

INSERT INTO @DPET
SELECT CONVERT(INT,Code),CONVERT(INT,ParentOrganizationCode_CODE),Name,ParentOrganizationCode_Name, OrganizationTypeCode_Name,Phone,Cellular,Fax,LocationID_Name,ShortName FROM [dbo].[VW_MDS_SCOrganization]
DECLARE @Name  VARCHAR(1000)
SELECT @Name = 'STRATHCONA COUNTY'

;WITH Selects AS (
        SELECT *
        FROM    @DPET
        WHERE   DEPT_NAME = @Name
        UNION ALL
        SELECT  t.*
        FROM    @DPET t INNER JOIN
                Selects s ON t.ParentCode = s.code
)
,

MyCTE AS (
  SELECT CODE,PARENTCODE, DEPT_NAME,TreeLevel=0,  TreePath=CAST(CODE AS VARCHAR(250)),OrganizationTypeCode_Name,Phone,Cellular,Fax,LocationID_Name,ShortName 
  FROM Selects T1
  WHERE DEPT_NAME ='STRATHCONA COUNTY'

  UNION ALL

  SELECT T2.CODE, t2.PARENTCODE, T2.DEPT_NAME,TreeLevel=TreeLevel + 1, CAST(TreePath + '.' + CAST(T2.CODE AS VARCHAR(250)) AS VARCHAR(250)) AS TreePath, T2.OrganizationTypeCode_Name,T2.Phone,t2.Cellular,t2.Fax,t2.LocationID_Name,t2.ShortName
  FROM Selects T2
  INNER JOIN MyCTE itms ON itms.CODE = T2.PARENTCODE
)
,
ORG AS (
SELECT ORG_NAME=DEPT_NAME,CODE,PARENT_CODE=PARENTCODE, PATH_NAME=Replicate('.', TreeLevel * 4)+DEPT_NAME , TREE_LEVEL=TreeLevel, TREE_PATH=TreePath,ORGANIZATION_TYPE=OrganizationTypeCode_Name,Phone,Cellular,Fax,LocationID_Name,ShortName
FROM  MyCTE 
)
,DIV  AS (
SELECT * FROM ORG
WHERE TREE_LEVEL =4)
,DEPT AS (
SELECT * FROM ORG
WHERE TREE_LEVEL =5) 


INSERT INTO @ORG
SELECT * FROM (
SELECT *, DISPLAYORDER= CASE WHEN DEPT = 'OFFICE OF THE MAYOR' THEN 1
WHEN  DEPT = 'OFFICE OF THE ELECTED OFFICIALS' THEN 2
WHEN  DEPT = 'Chief Commissioner' THEN 3
WHEN  DEPT IS NOT NULL  AND DEPT NOT IN ('OFFICE OF THE MAYOR','OFFICE OF THE ELECTED OFFICIALS','Chief Commissioner','')  THEN 4
ELSE 5
END
 FROM (
SELECT DIV=UPPER(CASE WHEN  ORG.TREE_LEVEL NOT IN ('0','1','2','3') THEN  DIV.ORG_NAME ELSE 
		CASE WHEN ORG.ORG_NAME in ('MAYOR','OFFICE OF THE MAYOR')  THEN 'OFFICE OF THE MAYOR' 
		WHEN ORG.ORG_NAME in ('COUNCIL','OFFICE OF THE ELECTED OFFICIALS') THEN 'OFFICE OF THE ELECTED OFFICIALS'
		WHEN ORG.ORG_NAME in ('Chief Commissioner','Corporate Services Division','Community Services Division','Infrastructure and Planning Services Division','Financial and Strategic Management Division') THEN  ('Chief Commissioner')
		ELSE ''
		END
END)
, 
DEPT=UPPER(CASE WHEN  ORG.TREE_LEVEL NOT IN ('0','1','2','3','4')THEN  DEPT.ORG_NAME ELSE 
		CASE WHEN ORG.ORG_NAME in ('MAYOR','OFFICE OF THE MAYOR')  THEN 'OFFICE OF THE MAYOR' 
		WHEN ORG.ORG_NAME in ('COUNCIL','OFFICE OF THE ELECTED OFFICIALS') THEN 'OFFICE OF THE ELECTED OFFICIALS'
		WHEN ORG.ORG_NAME in ('Chief Commissioner','Corporate Services Division','Community Services Division','Infrastructure and Planning Services Division','Financial and Strategic Management Division') THEN  ('Chief Commissioner')
		ELSE ''
		END
 END), 
 DEPT_SHORT_NAME=DEPT.ShortName,
 DEPT_ADDRESS=DEPT.LocationID_Name,DEPT_PHONE=DEPT.Phone,DEPT_CELLULAR=DEPT.Cellular,DEPT_FAX=DEPT.Fax,
 DEPT_LATITUDE=DL.Latitude,DEPT_LONGITUDE=DL.Longitude,
 ORG_NAME=UPPER(ORG.ORG_NAME),
 ORG_SHORT_NAME=ORG.ShortName,
 ORG.CODE,
 ORG_ADDRESS=ORG.LocationID_Name,ORG_PHONE=ORG.Phone,ORG_CELLULAR=ORG.Cellular,ORG_FAX=ORG.Fax,
 ORG_LATITUDE=OL.Latitude,ORG_LONGITUDE=OL.Longitude,
 ORG.PARENT_CODE,ORG.PATH_NAME,ORG.TREE_LEVEL,ORG.TREE_PATH,ORG.ORGANIZATION_TYPE
 
 
 FROM ORG
LEFT JOIN
DIV 
ON DIV.TREE_PATH = SUBSTRING(ORG.TREE_PATH,1,LEN(DIV.TREE_PATH))
LEFT JOIN
DEPT
ON DEPT.TREE_PATH = SUBSTRING(ORG.TREE_PATH,1,LEN(DEPT.TREE_PATH))
LEFT JOIN
[dbo].[VW_MDS_SCLocation] DL
ON DEPT.CODE =DL.Code
LEFT JOIN
[dbo].[VW_MDS_SCLocation] OL
ON DEPT.CODE =OL.Code
) a

) b


;
SELECT a.*,ContactCNT=1, IsManagerOrder=0,L.LeadGroup,IsDirector=CASE WHEN a.WorkingTitle ='Director' THEN 1 ELSE 0 END FROM (

SELECT *,FontBlod= CASE WHEN ContactLevel_Code <> '0'  THEN 1 ELSE 0 END, FontColor=CASE WHEN ContactLevel_Code NOT IN ('0','1')  THEN 'Black' ELSE 'Green' END  FROM (
SELECT D.*,Contactcode=CONVERT(INT,e1.code),e1.Name,e1.OrganizationCode_Name,e1.ParentOrganizationCode_Name,e1.WorkingTitle,e1.Email,WorkPhone=e1.Phone,WorkCellular=e1.Cellular, e1.ContactLevel_Code,e1.ContactLevel_Name ,e1.PrimaryReportTo_Code,e1.SecondaryReportTo_Code
  
 FROM 
 [dbo].[VW_MDS_SCContact] e1
  LEFT JOIN
  @ORG d 
 On d.ORG_NAME=e1.OrganizationCode_Name
 ) a
 ) a 
 LEFT JOIN
 (
SELECT LeadGroup=L0.code+'_000',Code,Name,OrganizationCode_Name FROM (
SELECT * 

FROM (
SELECT *
	  ,NBR= ROW_NUMBER() OVER (PARTITION BY Code ORDER BY ID  )
  FROM [dbo].[VW_MDS_SCContact] WHERE ContactLevel_Code =1 
  ) a WHERE nbr=1
) L0

UNION
(
SELECT LeadGroup=L.code+'_'+NL.code,NL.Code,NL.Name,NL.OrganizationCode_Name FROM (
SELECT * 

FROM (
SELECT *
	  ,NBR= ROW_NUMBER() OVER (PARTITION BY Code ORDER BY ID  )
  FROM [dbo].[VW_MDS_SCContact] WHERE ContactLevel_Code =1 
  ) a WHERE nbr=1
) L
RIGHT JOIN 
 (
SELECT * 

FROM (
SELECT *
	  ,NBR= ROW_NUMBER() OVER (PARTITION BY Code ORDER BY ID  )
  FROM [dbo].[VW_MDS_SCContact] WHERE ContactLevel_Code =0  
  ) a WHERE nbr=1
) NL
ON L.Code = NL.PrimaryReportTo_Code
)
) L 
ON a.Contactcode =L.Code


--WHERE ?= 'All' or Dept = (?)
ORDER BY DISPLAY_ORDER, DEPT,TREE_LEVEL DESC
,OrganizationCode_Name, CASE WHEN ContactLevel_Name = 'ServiceLine' THEN 0 WHEN ContactLevel_Name ='Director' THEN 1 WHEN ContactLevel_Name ='Manager' THEN 2 ELSE 3 END,TREE_PATH, LeadGroup, Contactcode
