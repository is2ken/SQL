DECLARE @MinDate DATE = '19900101',
        @MaxDate DATE = '20501231';
DECLARE @Date_BASE TABLE (DateKey INT,DateValue Date)

TRUNCATE TABLE [STG].[Date]
INSERT INTO @Date_BASE
SELECT CONVERT(INT,CONVERT(VARCHAR(7),Date,112)), Date FROM (
SELECT  TOP  (DATEDIFF(DAY, @MinDate, @MaxDate) + 1)
        Date = DATEADD(DAY, ROW_NUMBER() OVER(ORDER BY a.object_id) - 1, @MinDate)
FROM    sys.all_objects a

        CROSS JOIN sys.all_objects b
) c		;

INSERT INTO [STG].[Date]
SELECT DateKey,DateValue,
[Quarter],
[QuarterDESC] = CASE WHEN [Quarter] = 1 THEN 'First Quarter'
WHEN [Quarter] = 2 THEN 'Second Quarter'
WHEN [Quarter] = 3 THEN 'Third Quarter'
WHEN [Quarter] = 4 THEN 'Fourth Quarter' 
END,
[Month],[MonthDesc],
[Week],[Day],[Weekday],[WeekdayDesc]
 FROM (
SELECT *,[Quarter]=CONVERT (INT,DATEPART ( quarter , DateValue )),[Month]= CONVERT (INT,DATEPART ( mm , DateValue )),
[MonthDesc]=CONVERT(varchar(3), DATENAME(MONTH, DateValue)) ,
[Week]=CONVERT (INT,DATEPART ( wk , DateValue )),[Day]=CONVERT (INT,DATEPART ( dd , DateValue )),
[Weekday]=CONVERT (INT,DATEPART ( dw , DateValue )) ,[WeekdayDesc]=CONVERT(varchar(10), DATENAME(WEEKDAY, DateValue)) 
FROM @Date_BASE 
) a


