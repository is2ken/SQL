  DECLARE @Org TABLE (DEPT NVARCHAR(512),[Name] NVARCHAR(250),Code INT,  ShortName NVARCHAR(100),ParentOrgCode INT, ParentOrgName NVARCHAR(250),LocationID_Name NVARCHAR(250),Phone NVARCHAR(100),Fax Nvarchar(100),Cellular NVARCHAR(100),NBR INT)
  DECLARE @DEPT TABLE  (DEPT NVARCHAR(512),RecursiveCallNumber INT, [Name] NVARCHAR(250),Code INT, ShortName NVARCHAR(100),ParentOrganizationCode_Code INT, ParentOrganizationCode_Name NVARCHAR(250)
  ,[OrganizationTypeCode_Code] INT,OrganizationTypeCode_Name NVARCHAR(250))
  DECLARE @ORGNAME NVARCHAR(250)
  
  INSERT INTO @Org
  SELECT distinct
      DEPT=[ParentOrganizationCode_Name] +'\'+[Name]
      ,D.[Name]
      ,D.[Code]      
      ,D.[ShortName]	
      ,D.[ParentOrganizationCode_Code]
      ,D.[ParentOrganizationCode_Name]
	  ,D.LocationID_Name
	  ,D.Phone
	  ,D.Fax	 
	  ,D.Cellular
	  ,NBR=ROW_NUMBER() OVER (ORDER BY CONVERT(INT, [Code]))	   
  FROM [SC_DAALY].[dbo].[VW_MDS_SCOrganization] D
  WHERE D.OrganizationTypeCode_Name = ('Department')

  INSERT INTO @DEPT  
  SELECT DEPT,RecursiveCallNumber,NAME,Code,[ShortName],[ParentOrganizationCode_Code]
      ,[ParentOrganizationCode_Name]
      ,[OrganizationTypeCode_Code]
      ,[OrganizationTypeCode_Name] FROM [dbo].[udfGetDepartmentHierarchy]() a


SELECT DisplayOrder=CASE WHEN o.LocationID_Name is null then 'N/A' else o.LocationID_Name end, e.NAME,e.Phone,e.Cellular, d.DEPT,o.LocationID_Name FROM [SC_DAALY].[dbo].[VW_MDS_SCEmployee] e
LEFT JOIN @DEPT d ON e.OrganizationCode_Code = d.Code
LEFT JOIN @Org o ON e.OrganizationCode_Code = O.Code

WHERE e.NAME <>'ALL' --(?='All' Or d.Dept = (?))
 ORDER BY 1
