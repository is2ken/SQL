USE [SC_DW]
GO

/****** Object:  Table [CNF].[REF_LOAD_PARAMETER]    Script Date: 6/13/2018 10:18:35 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [CNF].[REF_LOAD_PARAMETER](
	[ID] [int] NULL,
	[TABLE_NAME] [varchar](100) NULL,
	[TYPE] [varchar](100) NULL,	 -- CODE Table;Time Dimension, Date Dimesion,Greography Dimension
	[DESCRIPTION] [varchar](512) NULL,
	[DATABASE_NAME] [varchar](50) NULL,
	[SCHEMA] [varchar](20) NULL,
	[SOURCE_DATABASE_NAME] [varchar](50) NULL,
	[SOURCE_SCHEMA] [varchar](20) NULL,
	[SOURCE_TABLE_NAME] [varchar](100) NULL,
	[SELECT_COLUMNS] [varchar](4000) NULL,
	[FILTER_CLAUSE] [varchar](1000) NULL,
	[BUSINESS_ID] [varchar](100) NULL,
	[ACTIVE_FLAG] [int] NULL
) ON [PRIMARY]
GO


