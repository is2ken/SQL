DECLARE @StartTime datetime = '2000-01-01 00:00:00',
    @EndTime datetime = '2000-01-02 00:00:01',
    @Interval int = 1 -- this can be changed.
DECLARE @t TABLE (TimeKey INT IDENTITY(1,1), TimeValue Time);
WITH cSequence AS
(
    SELECT
       @StartTime AS StartRange, 
       DATEADD(SECOND, @Interval, @StartTime) AS EndRange
    UNION ALL
    SELECT
      EndRange, 
      DATEADD(SECOND, @Interval, EndRange)
    FROM cSequence 
    WHERE DATEADD(SECOND, @Interval, EndRange) < @EndTime
)

INSERT INTO @t
SELECT TimeValue=CONVERT(time,StartRange) FROM cSequence OPTION (MAXRECURSION 0)

SELECT *,[GroupbyHour]=CONVERT(INT,CONVERT(VARCHAR(2),TimeValue)),[Groupby15Minutes]=CASE WHEN CONVERT(REAL,RIGHT(CONVERT(VARCHAR(5),TimeValue),2))/60 <=0.25 THEN 1 
WHEN CONVERT(REAL,RIGHT(CONVERT(VARCHAR(5),TimeValue),2))/60 >0.25 AND CONVERT(REAL,RIGHT(CONVERT(VARCHAR(5),TimeValue),2))/60 <=0.5 THEN 2
WHEN CONVERT(REAL,RIGHT(CONVERT(VARCHAR(5),TimeValue),2))/60 >0.5 AND CONVERT(REAL,RIGHT(CONVERT(VARCHAR(5),TimeValue),2))/60 <=0.75 THEN 3
WHEN CONVERT(REAL,RIGHT(CONVERT(VARCHAR(5),TimeValue),2))/60 >0.75 AND CONVERT(REAL,RIGHT(CONVERT(VARCHAR(5),TimeValue),2))/60 <=1 THEN 4 END
FROM @t
--WHERE TimeValue = CONVERT(time,'2001-06-15 18:16:41.000')

